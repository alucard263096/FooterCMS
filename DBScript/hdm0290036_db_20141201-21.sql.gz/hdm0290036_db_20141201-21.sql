-- MySQL dump 10.13  Distrib 5.1.48, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: hdm0290036_db
-- ------------------------------------------------------
-- Server version	5.1.48-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_access_right`
--

DROP TABLE IF EXISTS `tb_access_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_access_right` (
  `right_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `seq` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_access_right`
--

LOCK TABLES `tb_access_right` WRITE;
/*!40000 ALTER TABLE `tb_access_right` DISABLE KEYS */;
INSERT INTO `tb_access_right` VALUES (2,'Edit',2);
INSERT INTO `tb_access_right` VALUES (3,'Delete',3);
/*!40000 ALTER TABLE `tb_access_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_city`
--

DROP TABLE IF EXISTS `tb_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_city` (
  `serialId` int(11) NOT NULL,
  `cityId` varchar(20) DEFAULT NULL,
  `cityName` varchar(20) DEFAULT NULL,
  `cityUpId` varchar(20) DEFAULT NULL,
  `cityUpIdNum` int(11) DEFAULT NULL,
  `cityPath` varchar(100) DEFAULT NULL,
  `cityType` varchar(20) DEFAULT NULL,
  `cityTypeNum` int(11) DEFAULT NULL,
  `shortName` varchar(11) DEFAULT NULL,
  `spell` varchar(11) DEFAULT NULL,
  `areaId` varchar(11) DEFAULT NULL,
  `postCode` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`serialId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_city`
--

LOCK TABLES `tb_city` WRITE;
/*!40000 ALTER TABLE `tb_city` DISABLE KEYS */;
INSERT INTO `tb_city` VALUES (1,'001001001','北京','001001',1,'中国/北京','市',3,'dc','beijing','010','100010');
INSERT INTO `tb_city` VALUES (19,'001003001','石家庄','001003',3,'中国/河北/石家庄','市',3,'sjz','shijiazhuan','0311','050011');
INSERT INTO `tb_city` VALUES (20,'001003002','唐山','001003',3,'中国/河北/唐山','市',3,'ts','tangshan','0315','063006');
INSERT INTO `tb_city` VALUES (21,'001003003','秦皇岛','001003',3,'中国/河北/秦皇岛','市',3,'qhd','qinhuangdao','0335','066000');
INSERT INTO `tb_city` VALUES (22,'001003004','邯郸','001003',3,'中国/河北/邯郸','市',3,'hd','handan','0310','056002');
INSERT INTO `tb_city` VALUES (23,'001003005','邢台','001003',3,'中国/河北/邢台','市',3,'xt','xingtai','0319','054001');
INSERT INTO `tb_city` VALUES (24,'001003006','保定','001003',3,'中国/河北/保定','市',3,'bd','baoding','0312','071052');
INSERT INTO `tb_city` VALUES (25,'001003007','张家口','001003',3,'中国/河北/张家口','市',3,'zjk','zhangjiakou','0313','075061');
INSERT INTO `tb_city` VALUES (26,'001003008','承德','001003',3,'中国/河北/承德','市',3,'cd','chengde','0314','067000');
INSERT INTO `tb_city` VALUES (27,'001003009','沧州','001003',3,'中国/河北/沧州','市',3,'cz','cangzhou','0317','061001');
INSERT INTO `tb_city` VALUES (28,'001003010','廊坊','001003',3,'中国/河北/廊坊','市',3,'lf','langfang','0316','065000');
INSERT INTO `tb_city` VALUES (29,'001003011','衡水','001003',3,'中国/河北/衡水','市',3,'hs','hengshui','0318','053000');
INSERT INTO `tb_city` VALUES (30,'001004001','太原','001004',4,'中国/山西/太原','市',3,'ty','taiyuan','0351','030082');
INSERT INTO `tb_city` VALUES (31,'001004002','大同','001004',4,'中国/山西/大同','市',3,'dt','datong','0352','037008');
INSERT INTO `tb_city` VALUES (32,'001004003','阳泉','001004',4,'中国/山西/阳泉','市',3,'yq','yangquan','0353','045000');
INSERT INTO `tb_city` VALUES (33,'001004004','长治','001004',4,'中国/山西/长治','市',3,'cz','changzhi','0355','046000');
INSERT INTO `tb_city` VALUES (34,'001004005','晋城','001004',4,'中国/山西/晋城','市',3,'jc','jincheng','0356','048000');
INSERT INTO `tb_city` VALUES (35,'001004006','朔州','001004',4,'中国/山西/朔州','市',3,'sz','shuozhou','0349','036000');
INSERT INTO `tb_city` VALUES (36,'001004007','晋中','001004',4,'中国/山西/晋中','市',3,'jz','jinzhong','0354','030600');
INSERT INTO `tb_city` VALUES (37,'001004008','运城','001004',4,'中国/山西/运城','市',3,'yc','yuncheng','0359','044000');
INSERT INTO `tb_city` VALUES (38,'001004009','忻州','001004',4,'中国/山西/忻州','市',3,'xz','xinzhou','0350','034000');
INSERT INTO `tb_city` VALUES (39,'001004010','临汾','001004',4,'中国/山西/临汾','市',3,'lf','linfen','0357','041000');
INSERT INTO `tb_city` VALUES (40,'001004011','吕梁地','001004',4,'中国/山西/吕梁地','区',3,'lld','lvliangdi','0358','033000');
INSERT INTO `tb_city` VALUES (41,'001005001','呼和浩特','001005',5,'中国/内蒙古/呼和浩特','市',3,'hhht','huhehaote','0471','010020');
INSERT INTO `tb_city` VALUES (42,'001005002','包头','001005',5,'中国/内蒙古/包头','市',3,'bt','baotou','0472','014025');
INSERT INTO `tb_city` VALUES (43,'001005003','乌海','001005',5,'中国/内蒙古/乌海','市',3,'wh','wuhai','0473','016000');
INSERT INTO `tb_city` VALUES (44,'001005004','赤峰','001005',5,'中国/内蒙古/赤峰','市',3,'cf','chifeng','0476','024000');
INSERT INTO `tb_city` VALUES (45,'001005005','通辽','001005',5,'中国/内蒙古/通辽','市',3,'tl','tongliao','0475','028000');
INSERT INTO `tb_city` VALUES (46,'001005006','鄂尔多斯','001005',5,'中国/内蒙古/鄂尔多斯','市',3,'eeds','eerduosi','0477','017004');
INSERT INTO `tb_city` VALUES (47,'001005007','呼伦贝尔','001005',5,'中国/内蒙古/呼伦贝尔','市',3,'hlbe','hulunbeier','0470','021008');
INSERT INTO `tb_city` VALUES (48,'001005008','乌兰察布','001005',5,'中国/内蒙古/乌兰察布','盟',3,'wlcbm','wulanchabum','0474','012000');
INSERT INTO `tb_city` VALUES (49,'001005009','锡林郭勒','001005',5,'中国/内蒙古/锡林郭勒','盟',3,'xlglm','xilinguolem','0479','026021');
INSERT INTO `tb_city` VALUES (50,'001005010','巴彦淖尔','001005',5,'中国/内蒙古/巴彦淖尔','盟',3,'bynem','bayannaoerm','0478','015001');
INSERT INTO `tb_city` VALUES (51,'001005011','阿拉善','001005',5,'中国/内蒙古/阿拉善','盟',3,'alsm','alashanmeng','0483','750306');
INSERT INTO `tb_city` VALUES (52,'001005012','兴安','001005',5,'中国/内蒙古/兴安','盟',3,'xam','xinganmeng','0482','137401');
INSERT INTO `tb_city` VALUES (53,'001006001','沈阳','001006',6,'中国/辽宁/沈阳','市',3,'sy','shenyang','024','110013');
INSERT INTO `tb_city` VALUES (54,'001006002','大连','001006',6,'中国/辽宁/大连','市',3,'dl','dalian','0411','116011');
INSERT INTO `tb_city` VALUES (55,'001006003','鞍山','001006',6,'中国/辽宁/鞍山','市',3,'as','anshan','0412','114001');
INSERT INTO `tb_city` VALUES (56,'001006004','抚顺','001006',6,'中国/辽宁/抚顺','市',3,'fs','fushun','0413','113008');
INSERT INTO `tb_city` VALUES (57,'001006005','本溪','001006',6,'中国/辽宁/本溪','市',3,'bx','benxi','0414','117000');
INSERT INTO `tb_city` VALUES (58,'001006006','丹东','001006',6,'中国/辽宁/丹东','市',3,'dd','dandong','0415','118000');
INSERT INTO `tb_city` VALUES (59,'001006007','锦州','001006',6,'中国/辽宁/锦州','市',3,'jz','jinzhou','0416','121000');
INSERT INTO `tb_city` VALUES (60,'001006008','葫芦岛','001006',6,'中国/辽宁/葫芦岛','市',3,'hld','huludao','0429','125000');
INSERT INTO `tb_city` VALUES (61,'001006009','营口','001006',6,'中国/辽宁/营口','市',3,'yk','yingkou','0417','115003');
INSERT INTO `tb_city` VALUES (62,'001006010','盘锦','001006',6,'中国/辽宁/盘锦','市',3,'pj','panjin','0427','124010');
INSERT INTO `tb_city` VALUES (63,'001006011','阜新','001006',6,'中国/辽宁/阜新','市',3,'fx','fuxin','0418','123000');
INSERT INTO `tb_city` VALUES (64,'001006012','辽阳','001006',6,'中国/辽宁/辽阳','市',3,'ly','liaoyang','0419','111000');
INSERT INTO `tb_city` VALUES (65,'001006013','铁岭','001006',6,'中国/辽宁/铁岭','市',3,'tl','tieling','0410','112000');
INSERT INTO `tb_city` VALUES (66,'001006014','朝阳','001006',6,'中国/辽宁/朝阳','市',3,'cy','chaoyang','0421','122000');
INSERT INTO `tb_city` VALUES (67,'001007001','长春','001007',7,'中国/吉林/长春','市',3,'cc','changchun','0431','130061');
INSERT INTO `tb_city` VALUES (68,'001007002','吉林','001007',7,'中国/吉林/吉林','市',3,'jl','jilin','0432','132011');
INSERT INTO `tb_city` VALUES (69,'001007003','四平','001007',7,'中国/吉林/四平','市',3,'sp','siping','0434','136000');
INSERT INTO `tb_city` VALUES (70,'001007004','辽源','001007',7,'中国/吉林/辽源','市',3,'ly','liaoyuan','0437','136200');
INSERT INTO `tb_city` VALUES (71,'001007005','通化','001007',7,'中国/吉林/通化','市',3,'th','tonghua','0435','134001');
INSERT INTO `tb_city` VALUES (72,'001007006','白山','001007',7,'中国/吉林/白山','市',3,'bs','baishan','0439','134300');
INSERT INTO `tb_city` VALUES (73,'001007007','松原','001007',7,'中国/吉林/松原','市',3,'sy','songyuan','0438','138000');
INSERT INTO `tb_city` VALUES (74,'001007008','白城','001007',7,'中国/吉林/白城','市',3,'bc','baicheng','0436','137000');
INSERT INTO `tb_city` VALUES (75,'001007009','延边','001007',7,'中国/吉林/延边','州',3,'yb','yanbian','0433','133000');
INSERT INTO `tb_city` VALUES (76,'001008001','哈尔滨','001008',8,'中国/黑龙江/哈尔滨','市',3,'heb','haerbin','0451','150010');
INSERT INTO `tb_city` VALUES (77,'001008002','齐齐哈尔','001008',8,'中国/黑龙江/齐齐哈尔','市',3,'qqhe','qiqihaer','0452','161005');
INSERT INTO `tb_city` VALUES (78,'001008003','鹤岗','001008',8,'中国/黑龙江/鹤岗','市',3,'hg','hegang','0468','154100');
INSERT INTO `tb_city` VALUES (79,'001008004','双鸭山','001008',8,'中国/黑龙江/双鸭山','市',3,'sys','shuangyasha','0469','155100');
INSERT INTO `tb_city` VALUES (80,'001008005','鸡西','001008',8,'中国/黑龙江/鸡西','市',3,'jx','jixi','0467','158100');
INSERT INTO `tb_city` VALUES (81,'001008006','大庆','001008',8,'中国/黑龙江/大庆','市',3,'dq','daqing','0459','163311');
INSERT INTO `tb_city` VALUES (82,'001008007','伊春','001008',8,'中国/黑龙江/伊春','市',3,'yc','yichun','0458','153000');
INSERT INTO `tb_city` VALUES (83,'001008008','牡丹江','001008',8,'中国/黑龙江/牡丹江','市',3,'mdj','mudanjiang','0453','157000');
INSERT INTO `tb_city` VALUES (84,'001008009','佳木斯','001008',8,'中国/黑龙江/佳木斯','市',3,'jms','jiamusi','0454','154002');
INSERT INTO `tb_city` VALUES (85,'001008010','七台河','001008',8,'中国/黑龙江/七台河','市',3,'qth','qitaihe','0464','154600');
INSERT INTO `tb_city` VALUES (86,'001008011','黑河','001008',8,'中国/黑龙江/黑河','市',3,'hh','heihe','0456','164300');
INSERT INTO `tb_city` VALUES (87,'001008012','绥化','001008',8,'中国/黑龙江/绥化','市',3,'sh','suihua','0455','152000');
INSERT INTO `tb_city` VALUES (88,'001008013','大兴安岭','001008',8,'中国/黑龙江/大兴安岭','地区',3,'dxald','daxinganlin','0457','165000');
INSERT INTO `tb_city` VALUES (89,'001010001','南京','001010',10,'中国/江苏/南京','市',3,'nj','nanjing','025','210008');
INSERT INTO `tb_city` VALUES (90,'001010002','徐州','001010',10,'中国/江苏/徐州','市',3,'xz','xuzhou','0516','221003');
INSERT INTO `tb_city` VALUES (91,'001010003','连云港','001010',10,'中国/江苏/连云港','市',3,'lyg','lianyungang','0518','222002');
INSERT INTO `tb_city` VALUES (92,'001010004','淮安','001010',10,'中国/江苏/淮安','市',3,'ha','huaian','0517','223001');
INSERT INTO `tb_city` VALUES (93,'001010005','宿迁','001010',10,'中国/江苏/宿迁','市',3,'sq','suqian','0527','223800');
INSERT INTO `tb_city` VALUES (94,'001010006','盐城','001010',10,'中国/江苏/盐城','市',3,'yc','yancheng','0515','224005');
INSERT INTO `tb_city` VALUES (95,'001010007','扬州','001010',10,'中国/江苏/扬州','市',3,'yz','yangzhou','0514','225002');
INSERT INTO `tb_city` VALUES (96,'001010008','泰州','001010',10,'中国/江苏/泰州','市',3,'tz','taizhou','0523','225300');
INSERT INTO `tb_city` VALUES (97,'001010009','南通','001010',10,'中国/江苏/南通','市',3,'nt','nantong','0513','226001');
INSERT INTO `tb_city` VALUES (98,'001010010','镇江','001010',10,'中国/江苏/镇江','市',3,'zj','zhenjiang','0511','212001');
INSERT INTO `tb_city` VALUES (99,'001010011','常州','001010',10,'中国/江苏/常州','市',3,'cz','changzhou','0519','213003');
INSERT INTO `tb_city` VALUES (100,'001010012','无锡','001010',10,'中国/江苏/无锡','市',3,'wx','wuxi','0510','214001');
INSERT INTO `tb_city` VALUES (101,'001010013','苏州','001010',10,'中国/江苏/苏州','市',3,'sz','suzhou','0512','215002');
INSERT INTO `tb_city` VALUES (102,'001011001','杭州','001011',11,'中国/浙江/杭州','市',3,'hz','hangzhou','0571','310026');
INSERT INTO `tb_city` VALUES (103,'001011002','宁波','001011',11,'中国/浙江/宁波','市',3,'nb','ningbo','0574','315000');
INSERT INTO `tb_city` VALUES (104,'001011003','温州','001011',11,'中国/浙江/温州','市',3,'wz','wenzhou','0577','325000');
INSERT INTO `tb_city` VALUES (105,'001011004','嘉兴','001011',11,'中国/浙江/嘉兴','市',3,'jx','jiaxing','0573','314000');
INSERT INTO `tb_city` VALUES (106,'001011005','湖州','001011',11,'中国/浙江/湖州','市',3,'hz','huzhou','0572','313000');
INSERT INTO `tb_city` VALUES (107,'001011006','绍兴','001011',11,'中国/浙江/绍兴','市',3,'sx','shaoxing','0575','312000');
INSERT INTO `tb_city` VALUES (108,'001011007','金华','001011',11,'中国/浙江/金华','市',3,'jh','jinhua','0579','321000');
INSERT INTO `tb_city` VALUES (109,'001011008','衢州','001011',11,'中国/浙江/衢州','市',3,'xz','xuzhou','0570','324002');
INSERT INTO `tb_city` VALUES (110,'001011009','舟山','001011',11,'中国/浙江/舟山','市',3,'zs','zhoushan','0580','316000');
INSERT INTO `tb_city` VALUES (111,'001011010','台州','001011',11,'中国/浙江/台州','市',3,'tz','taizhou','0576','318000');
INSERT INTO `tb_city` VALUES (112,'001011011','丽水','001011',11,'中国/浙江/丽水','市',3,'ls','lishui','0578','323000');
INSERT INTO `tb_city` VALUES (113,'001012001','合肥','001012',12,'中国/安徽/合肥','市',3,'hf','hefei','0551','230001');
INSERT INTO `tb_city` VALUES (114,'001012002','芜湖','001012',12,'中国/安徽/芜湖','市',3,'wh','wuhu','0553','241000');
INSERT INTO `tb_city` VALUES (115,'001012003','蚌埠','001012',12,'中国/安徽/蚌埠','市',3,'bb','bangbu','0552','233000');
INSERT INTO `tb_city` VALUES (116,'001012004','淮南','001012',12,'中国/安徽/淮南','市',3,'hn','huainan','0554','232000');
INSERT INTO `tb_city` VALUES (117,'001012005','马鞍山','001012',12,'中国/安徽/马鞍山','市',3,'mas','maanshan','0555','243000');
INSERT INTO `tb_city` VALUES (118,'001012006','淮北','001012',12,'中国/安徽/淮北','市',3,'hb','huaibei','0561','235000');
INSERT INTO `tb_city` VALUES (119,'001012007','铜陵','001012',12,'中国/安徽/铜陵','市',3,'tl','tongling','0562','244000');
INSERT INTO `tb_city` VALUES (120,'001012008','安庆','001012',12,'中国/安徽/安庆','市',3,'aq','anqing','0556','246001');
INSERT INTO `tb_city` VALUES (121,'001012009','黄山','001012',12,'中国/安徽/黄山','市',3,'hs','huangshan','0559','245000');
INSERT INTO `tb_city` VALUES (122,'001012010','滁州','001012',12,'中国/安徽/滁州','市',3,'cz','chuzhou','0550','239001');
INSERT INTO `tb_city` VALUES (123,'001012011','阜阳','001012',12,'中国/安徽/阜阳','市',3,'fy','fuyang','0558','236033');
INSERT INTO `tb_city` VALUES (124,'001012012','宿州','001012',12,'中国/安徽/宿州','市',3,'sz','suzhou','0557','234000');
INSERT INTO `tb_city` VALUES (125,'001012013','巢湖','001012',12,'中国/安徽/巢湖','市',3,'ch','chaohu','0565','238000');
INSERT INTO `tb_city` VALUES (126,'001012014','六安','001012',12,'中国/安徽/六安','市',3,'la','liuan','0564','237002');
INSERT INTO `tb_city` VALUES (127,'001012015','亳州','001012',12,'中国/安徽/亳州','市',3,'hz','haozhou','0558','236802');
INSERT INTO `tb_city` VALUES (128,'001012016','池州','001012',12,'中国/安徽/池州','市',3,'cz','chizhou','0566','247100');
INSERT INTO `tb_city` VALUES (129,'001012017','宣城','001012',12,'中国/安徽/宣城','市',3,'xc','xuancheng','0563','242000');
INSERT INTO `tb_city` VALUES (130,'001013001','福州','001013',13,'中国/福建/福州','市',3,'fz','fuzhou','0591','350001');
INSERT INTO `tb_city` VALUES (131,'001013002','厦门','001013',13,'中国/福建/厦门','市',3,'xm','xiamen','0592','361012');
INSERT INTO `tb_city` VALUES (132,'001013003','三明','001013',13,'中国/福建/三明','市',3,'sm','sanming','0598','365000');
INSERT INTO `tb_city` VALUES (133,'001013004','莆田','001013',13,'中国/福建/莆田','市',3,'pt','putian','0594','351100');
INSERT INTO `tb_city` VALUES (134,'001013005','泉州','001013',13,'中国/福建/泉州','市',3,'qz','quanzhou','0595','362000');
INSERT INTO `tb_city` VALUES (135,'001013006','漳州','001013',13,'中国/福建/漳州','市',3,'zz','zhangzhou','0596','363000');
INSERT INTO `tb_city` VALUES (136,'001013007','南平','001013',13,'中国/福建/南平','市',3,'np','nanping','0599','353000');
INSERT INTO `tb_city` VALUES (137,'001013008','龙岩','001013',13,'中国/福建/龙岩','市',3,'ly','longyan','0597','364000');
INSERT INTO `tb_city` VALUES (138,'001013009','宁德','001013',13,'中国/福建/宁德','市',3,'nd','ningde','0593','352100');
INSERT INTO `tb_city` VALUES (139,'001014001','南昌','001014',14,'中国/江西/南昌','市',3,'nc','nanchang','0791','330008');
INSERT INTO `tb_city` VALUES (140,'001014002','景德镇','001014',14,'中国/江西/景德镇','市',3,'jdz','jingdezhen','0798','333000');
INSERT INTO `tb_city` VALUES (141,'001014003','萍乡','001014',14,'中国/江西/萍乡','市',3,'px','pingxiang','0799','337002');
INSERT INTO `tb_city` VALUES (142,'001014004','九江','001014',14,'中国/江西/九江','市',3,'jj','jiujiang','0792','332000');
INSERT INTO `tb_city` VALUES (143,'001014005','新余','001014',14,'中国/江西/新余','市',3,'xy','xinyu','0790','336525');
INSERT INTO `tb_city` VALUES (144,'001014006','鹰潭','001014',14,'中国/江西/鹰潭','市',3,'yt','yingtan','0701','335001');
INSERT INTO `tb_city` VALUES (145,'001014007','赣州','001014',14,'中国/江西/赣州','市',3,'gz','ganzhou','0797','341000');
INSERT INTO `tb_city` VALUES (146,'001014008','吉安','001014',14,'中国/江西/吉安','市',3,'ja','jian','0796','343000');
INSERT INTO `tb_city` VALUES (147,'001014009','宜春','001014',14,'中国/江西/宜春','市',3,'yc','yichun','0795','336000');
INSERT INTO `tb_city` VALUES (148,'001014010','抚州','001014',14,'中国/江西/抚州','市',3,'fz','fuzhou','0794','344000');
INSERT INTO `tb_city` VALUES (149,'001014011','上饶','001014',14,'中国/江西/上饶','市',3,'sr','shangrao','0793','334000');
INSERT INTO `tb_city` VALUES (150,'001015001','济南','001015',15,'中国/山东/济南','市',3,'jn','jinan','0531','250001');
INSERT INTO `tb_city` VALUES (151,'001015002','青岛','001015',15,'中国/山东/青岛','市',3,'qd','qingdao','0532','266001');
INSERT INTO `tb_city` VALUES (152,'001015003','淄博','001015',15,'中国/山东/淄博','市',3,'zb','zibo','0533','255039');
INSERT INTO `tb_city` VALUES (153,'001015004','枣庄','001015',15,'中国/山东/枣庄','市',3,'zz','zaozhuang','0632','277101');
INSERT INTO `tb_city` VALUES (154,'001015005','东营','001015',15,'中国/山东/东营','市',3,'dy','dongying','0546','257093');
INSERT INTO `tb_city` VALUES (155,'001015006','潍坊','001015',15,'中国/山东/潍坊','市',3,'wf','weifang','0536','261041');
INSERT INTO `tb_city` VALUES (156,'001015007','烟台','001015',15,'中国/山东/烟台','市',3,'yt','yantai','0535','264001');
INSERT INTO `tb_city` VALUES (157,'001015008','威海','001015',15,'中国/山东/威海','市',3,'wh','weihai','0631','264200');
INSERT INTO `tb_city` VALUES (158,'001015009','济宁','001015',15,'中国/山东/济宁','市',3,'jn','jining','0537','272119');
INSERT INTO `tb_city` VALUES (159,'001015010','泰安','001015',15,'中国/山东/泰安','市',3,'ta','taian','0538','271000');
INSERT INTO `tb_city` VALUES (160,'001015011','日照','001015',15,'中国/山东/日照','市',3,'rz','rizhao','0633','276800');
INSERT INTO `tb_city` VALUES (161,'001015012','莱芜','001015',15,'中国/山东/莱芜','市',3,'lw','laiwu','0634','271100');
INSERT INTO `tb_city` VALUES (162,'001015013','临沂','001015',15,'中国/山东/临沂','市',3,'ly','linyi','0539','276001');
INSERT INTO `tb_city` VALUES (163,'001015014','德州','001015',15,'中国/山东/德州','市',3,'dz','dezhou','0534','253012');
INSERT INTO `tb_city` VALUES (164,'001015015','聊城','001015',15,'中国/山东/聊城','市',3,'lc','liaocheng','0635','252052');
INSERT INTO `tb_city` VALUES (165,'001015016','滨州','001015',15,'中国/山东/滨州','市',3,'bz','binzhou','0543','256619');
INSERT INTO `tb_city` VALUES (166,'001015017','菏泽','001015',15,'中国/山东/菏泽','市',3,'hz','heze','0530','274020');
INSERT INTO `tb_city` VALUES (167,'001016001','郑州','001016',16,'中国/河南/郑州','市',3,'zz','zhengzhou','0371','450006');
INSERT INTO `tb_city` VALUES (168,'001016002','开封','001016',16,'中国/河南/开封','市',3,'kf','kaifeng','0378','475001');
INSERT INTO `tb_city` VALUES (169,'001016003','洛阳','001016',16,'中国/河南/洛阳','市',3,'ly','luoyang','0379','471000');
INSERT INTO `tb_city` VALUES (170,'001016004','平顶山','001016',16,'中国/河南/平顶山','市',3,'pds','pingdingsha','0375','467000');
INSERT INTO `tb_city` VALUES (171,'001016005','焦作','001016',16,'中国/河南/焦作','市',3,'jz','jiaozuo','0391','454002');
INSERT INTO `tb_city` VALUES (172,'001016006','鹤壁','001016',16,'中国/河南/鹤壁','市',3,'hb','hebi','0392','458030');
INSERT INTO `tb_city` VALUES (173,'001016007','新乡','001016',16,'中国/河南/新乡','市',3,'xx','xinxiang','0373','453000');
INSERT INTO `tb_city` VALUES (174,'001016008','安阳','001016',16,'中国/河南/安阳','市',3,'ay','anyang','0372','455000');
INSERT INTO `tb_city` VALUES (175,'001016009','濮阳','001016',16,'中国/河南/濮阳','市',3,'y','yang','0393','457000');
INSERT INTO `tb_city` VALUES (176,'001016010','许昌','001016',16,'中国/河南/许昌','市',3,'xc','xuchang','0374','461000');
INSERT INTO `tb_city` VALUES (177,'001016011','漯河','001016',16,'中国/河南/漯河','市',3,'h','he','0395','462000');
INSERT INTO `tb_city` VALUES (178,'001016012','三门峡','001016',16,'中国/河南/三门峡','市',3,'smx','sanmenxia','0398','472000');
INSERT INTO `tb_city` VALUES (179,'001016013','南阳','001016',16,'中国/河南/南阳','市',3,'ny','nanyang','0377','473002');
INSERT INTO `tb_city` VALUES (180,'001016014','商丘','001016',16,'中国/河南/商丘','市',3,'sq','shangqiu','0370','476000');
INSERT INTO `tb_city` VALUES (181,'001016015','信阳','001016',16,'中国/河南/信阳','市',3,'xy','xinyang','0376','464000');
INSERT INTO `tb_city` VALUES (182,'001016016','周口','001016',16,'中国/河南/周口','市',3,'zk','zhoukou','0394','466000');
INSERT INTO `tb_city` VALUES (183,'001016017','驻马店','001016',16,'中国/河南/驻马店','市',3,'zmd','zhumadian','0396','463000');
INSERT INTO `tb_city` VALUES (184,'001016018','直辖行政单位','001016',16,'中国/河南/直辖行政单位','null',3,'zxxzdw','zhixiaxingz','0391		','454650');
INSERT INTO `tb_city` VALUES (185,'001017001','武汉','001017',17,'中国/湖北/武汉','市',3,'wh','wuhan','027','430014');
INSERT INTO `tb_city` VALUES (186,'001017002','黄石','001017',17,'中国/湖北/黄石','市',3,'hs','huangshi','0714','435003');
INSERT INTO `tb_city` VALUES (187,'001017003','襄樊','001017',17,'中国/湖北/襄樊','市',3,'xf','xiangfan','0710','441021');
INSERT INTO `tb_city` VALUES (188,'001017004','十堰','001017',17,'中国/湖北/十堰','市',3,'sy','shiyan','0719','442000');
INSERT INTO `tb_city` VALUES (189,'001017005','荆州','001017',17,'中国/湖北/荆州','市',3,'jz','jingzhou','0716','434000');
INSERT INTO `tb_city` VALUES (190,'001017006','宜昌','001017',17,'中国/湖北/宜昌','市',3,'yc','yichang','0717','443000');
INSERT INTO `tb_city` VALUES (191,'001017007','荆门','001017',17,'中国/湖北/荆门','市',3,'jm','jingmen','0724','448000');
INSERT INTO `tb_city` VALUES (192,'001017008','鄂州','001017',17,'中国/湖北/鄂州','市',3,'ez','ezhou','0711','436000');
INSERT INTO `tb_city` VALUES (193,'001017009','孝感','001017',17,'中国/湖北/孝感','市',3,'xg','xiaogan','0712','432100');
INSERT INTO `tb_city` VALUES (194,'001017010','黄冈','001017',17,'中国/湖北/黄冈','市',3,'hg','huanggang','0713','438000');
INSERT INTO `tb_city` VALUES (195,'001017011','咸宁','001017',17,'中国/湖北/咸宁','市',3,'xn','xianning','0715','437000');
INSERT INTO `tb_city` VALUES (196,'001017012','随州','001017',17,'中国/湖北/随州','市',3,'sz','suizhou','0722','441300');
INSERT INTO `tb_city` VALUES (197,'001017013','恩施','001017',17,'中国/湖北/恩施','州',3,'es','enshi','0718','445000');
INSERT INTO `tb_city` VALUES (198,'001017014','直辖行政单位','001017',17,'中国/湖北/直辖行政单位','null',3,'zxxzdw','zhixiaxingz','0719','442400');
INSERT INTO `tb_city` VALUES (199,'001018001','长沙','001018',18,'中国/湖南/长沙','市',3,'cs','changsha','0731','410005');
INSERT INTO `tb_city` VALUES (200,'001018002','株洲','001018',18,'中国/湖南/株洲','市',3,'zz','zhuzhou','0733','412000');
INSERT INTO `tb_city` VALUES (201,'001018003','湘潭','001018',18,'中国/湖南/湘潭','市',3,'xt','xiangtan','0732','411100');
INSERT INTO `tb_city` VALUES (202,'001018004','衡阳','001018',18,'中国/湖南/衡阳','市',3,'hy','hengyang','0734','421001');
INSERT INTO `tb_city` VALUES (203,'001018005','邵阳','001018',18,'中国/湖南/邵阳','市',3,'sy','shaoyang','0739','422000');
INSERT INTO `tb_city` VALUES (204,'001018006','岳阳','001018',18,'中国/湖南/岳阳','市',3,'yy','yueyang','0730','414000');
INSERT INTO `tb_city` VALUES (205,'001018007','常德','001018',18,'中国/湖南/常德','市',3,'cd','changde','0736','415000');
INSERT INTO `tb_city` VALUES (206,'001018008','张家界','001018',18,'中国/湖南/张家界','市',3,'zjj','zhangjiajie','0744','427000');
INSERT INTO `tb_city` VALUES (207,'001018009','益阳','001018',18,'中国/湖南/益阳','市',3,'yy','yiyang','0737','413000');
INSERT INTO `tb_city` VALUES (208,'001018010','郴州','001018',18,'中国/湖南/郴州','市',3,'cz','chenzhou','0735','423000');
INSERT INTO `tb_city` VALUES (209,'001018011','永州','001018',18,'中国/湖南/永州','市',3,'yz','yongzhou','0746','425000');
INSERT INTO `tb_city` VALUES (210,'001018012','怀化','001018',18,'中国/湖南/怀化','市',3,'hh','huaihua','0745','418000');
INSERT INTO `tb_city` VALUES (211,'001018013','娄底','001018',18,'中国/湖南/娄底','市',3,'ld','loudi','0738','417000');
INSERT INTO `tb_city` VALUES (212,'001018014','湘西','001018',18,'中国/湖南/湘西','州',3,'xx','xiangxi','0743','416000');
INSERT INTO `tb_city` VALUES (213,'001019001','广州','001019',19,'中国/广东/广州','市',3,'gz','guangzhou','020','510130');
INSERT INTO `tb_city` VALUES (214,'001019002','深圳','001019',19,'中国/广东/深圳','市',3,'sz','shenzhen','0755','518027');
INSERT INTO `tb_city` VALUES (215,'001019003','珠海','001019',19,'中国/广东/珠海','市',3,'zh','zhuhai','0756','519000');
INSERT INTO `tb_city` VALUES (216,'001019004','汕头','001019',19,'中国/广东/汕头','市',3,'st','shantou','0754','515031');
INSERT INTO `tb_city` VALUES (217,'001019005','韶关','001019',19,'中国/广东/韶关','市',3,'sg','shaoguan','0751','512000');
INSERT INTO `tb_city` VALUES (218,'001019006','河源','001019',19,'中国/广东/河源','市',3,'hy','heyuan','0762','517001');
INSERT INTO `tb_city` VALUES (219,'001019007','梅州','001019',19,'中国/广东/梅州','市',3,'mz','meizhou','0753','514021');
INSERT INTO `tb_city` VALUES (220,'001019008','惠州','001019',19,'中国/广东/惠州','市',3,'hz','huizhou','0752','516001');
INSERT INTO `tb_city` VALUES (221,'001019009','汕尾','001019',19,'中国/广东/汕尾','市',3,'sw','shanwei','0660','516601');
INSERT INTO `tb_city` VALUES (222,'001019010','东莞','001019',19,'中国/广东/东莞','市',3,'d','dongwan','0769','523003');
INSERT INTO `tb_city` VALUES (223,'001019011','中山','001019',19,'中国/广东/中山','市',3,'zs','zhongshan','0760','528403');
INSERT INTO `tb_city` VALUES (224,'001019012','江门','001019',19,'中国/广东/江门','市',3,'jm','jiangmen','0750','529020');
INSERT INTO `tb_city` VALUES (225,'001019013','佛山','001019',19,'中国/广东/佛山','市',3,'fs','foshan','0757','528000');
INSERT INTO `tb_city` VALUES (226,'001019014','阳江','001019',19,'中国/广东/阳江','市',3,'yj','yangjiang','0662','529525');
INSERT INTO `tb_city` VALUES (227,'001019015','湛江','001019',19,'中国/广东/湛江','市',3,'zj','zhanjiang','0759','524038');
INSERT INTO `tb_city` VALUES (228,'001019016','茂名','001019',19,'中国/广东/茂名','市',3,'mm','maoming','0668','525011');
INSERT INTO `tb_city` VALUES (229,'001019017','肇庆','001019',19,'中国/广东/肇庆','市',3,'zq','zhaoqing','0758','526060');
INSERT INTO `tb_city` VALUES (230,'001019018','清远','001019',19,'中国/广东/清远','市',3,'qy','qingyuan','0763','511500');
INSERT INTO `tb_city` VALUES (231,'001019019','潮州','001019',19,'中国/广东/潮州','市',3,'cz','chaozhou','0768','521000');
INSERT INTO `tb_city` VALUES (232,'001019020','揭阳','001019',19,'中国/广东/揭阳','市',3,'jy','jieyang','0663','522000');
INSERT INTO `tb_city` VALUES (233,'001019021','云浮','001019',19,'中国/广东/云浮','市',3,'yf','yunfu','0766','527300');
INSERT INTO `tb_city` VALUES (234,'001020001','南宁','001020',20,'中国/广西/南宁','市',3,'nn','nanning','0771','530012');
INSERT INTO `tb_city` VALUES (235,'001020002','柳州','001020',20,'中国/广西/柳州','市',3,'lz','liuzhou','0772','545001');
INSERT INTO `tb_city` VALUES (236,'001020003','桂林','001020',20,'中国/广西/桂林','市',3,'gl','guilin','0773','541002');
INSERT INTO `tb_city` VALUES (237,'001020004','梧州','001020',20,'中国/广西/梧州','市',3,'wz','wuzhou','0774','543000');
INSERT INTO `tb_city` VALUES (238,'001020005','北海','001020',20,'中国/广西/北海','市',3,'bh','beihai','0779','536000');
INSERT INTO `tb_city` VALUES (239,'001020006','防城港','001020',20,'中国/广西/防城港','市',3,'fcg','fangchengga','0770','538001');
INSERT INTO `tb_city` VALUES (240,'001020007','钦州','001020',20,'中国/广西/钦州','市',3,'qz','qinzhou','0777','535000');
INSERT INTO `tb_city` VALUES (241,'001020008','贵港','001020',20,'中国/广西/贵港','市',3,'gg','guigang','0775','537100');
INSERT INTO `tb_city` VALUES (242,'001020009','玉林','001020',20,'中国/广西/玉林','市',3,'yl','yulin','0775','537000');
INSERT INTO `tb_city` VALUES (243,'001020010','百色','001020',20,'中国/广西/百色','市',3,'bs','baise','0776','533000');
INSERT INTO `tb_city` VALUES (244,'001020011','贺州','001020',20,'中国/广西/贺州','市',3,'hz','hezhou','0774','542800');
INSERT INTO `tb_city` VALUES (245,'001020012','河池','001020',20,'中国/广西/河池','市',3,'hc','hechi','0778','547000');
INSERT INTO `tb_city` VALUES (246,'001020013','来宾','001020',20,'中国/广西/来宾','市',3,'lb','laibin','0772','null');
INSERT INTO `tb_city` VALUES (247,'001020014','崇左','001020',20,'中国/广西/崇左','市',3,'cz','chongzuo','null','null');
INSERT INTO `tb_city` VALUES (248,'001021001','海口','001021',21,'中国/海南/海口','市',3,'hk','haikou','0898','570102');
INSERT INTO `tb_city` VALUES (249,'001021002','三亚','001021',21,'中国/海南/三亚','市',3,'sy','sanya','0898','572002');
INSERT INTO `tb_city` VALUES (250,'001021003','省直辖行政单位','001021',21,'中国/海南/省直辖行政单位','null',3,'zxxzdw','zhixiaxingz','0898','571800');
INSERT INTO `tb_city` VALUES (251,'001023001','成都','001023',23,'中国/四川/成都','市',3,'cd','chengdu','028','610015');
INSERT INTO `tb_city` VALUES (252,'001023002','自贡','001023',23,'中国/四川/自贡','市',3,'zg','zigong','0813','643000');
INSERT INTO `tb_city` VALUES (253,'001023003','攀枝花','001023',23,'中国/四川/攀枝花','市',3,'pzh','panzhihua','0812','617000');
INSERT INTO `tb_city` VALUES (254,'001023004','泸州','001023',23,'中国/四川/泸州','市',3,'lz','luzhou','0830','646000');
INSERT INTO `tb_city` VALUES (255,'001023005','德阳','001023',23,'中国/四川/德阳','市',3,'dy','deyang','0838','618000');
INSERT INTO `tb_city` VALUES (256,'001023006','绵阳','001023',23,'中国/四川/绵阳','市',3,'my','mianyang','0816','621000');
INSERT INTO `tb_city` VALUES (257,'001023007','广元','001023',23,'中国/四川/广元','市',3,'gy','guangyuan','0839','628017');
INSERT INTO `tb_city` VALUES (258,'001023008','遂宁','001023',23,'中国/四川/遂宁','市',3,'sn','suining','0825','629000');
INSERT INTO `tb_city` VALUES (259,'001023009','内江','001023',23,'中国/四川/内江','市',3,'nj','neijiang','0832','641000');
INSERT INTO `tb_city` VALUES (260,'001023010','乐山','001023',23,'中国/四川/乐山','市',3,'ls','leshan','0833','614000');
INSERT INTO `tb_city` VALUES (261,'001023011','南充','001023',23,'中国/四川/南充','市',3,'nc','nanchong','0817','637000');
INSERT INTO `tb_city` VALUES (262,'001023012','宜宾','001023',23,'中国/四川/宜宾','市',3,'yb','yibin','0831','644000');
INSERT INTO `tb_city` VALUES (263,'001023013','广安','001023',23,'中国/四川/广安','市',3,'ga','guangan','0826','638500');
INSERT INTO `tb_city` VALUES (264,'001023014','达州','001023',23,'中国/四川/达州','市',3,'dz','dazhou','0818','635000');
INSERT INTO `tb_city` VALUES (265,'001023015','眉山','001023',23,'中国/四川/眉山','市',3,'ms','meishan','0833','620010');
INSERT INTO `tb_city` VALUES (266,'001023016','雅安','001023',23,'中国/四川/雅安','市',3,'ya','yaan','0835','625000');
INSERT INTO `tb_city` VALUES (267,'001023017','巴中','001023',23,'中国/四川/巴中','市',3,'bz','bazhong','0827','636600');
INSERT INTO `tb_city` VALUES (268,'001023018','资阳','001023',23,'中国/四川/资阳','市',3,'zy','ziyang','0832','641300');
INSERT INTO `tb_city` VALUES (269,'001023019','阿坝','001023',23,'中国/四川/阿坝','州',3,'ab','aba','0837','624000');
INSERT INTO `tb_city` VALUES (270,'001023020','甘孜','001023',23,'中国/四川/甘孜','州',3,'gz','ganzi','0836','626000');
INSERT INTO `tb_city` VALUES (271,'001023021','凉山','001023',23,'中国/四川/凉山','州',3,'ls','liangshan','0834','615000');
INSERT INTO `tb_city` VALUES (272,'001024001','贵阳','001024',24,'中国/贵州/贵阳','市',3,'gy','guiyang','0851','550003');
INSERT INTO `tb_city` VALUES (273,'001024002','六盘水','001024',24,'中国/贵州/六盘水','市',3,'lps','liupanshui','0858','553001');
INSERT INTO `tb_city` VALUES (274,'001024003','遵义','001024',24,'中国/贵州/遵义','市',3,'zy','zunyi','0852','563000');
INSERT INTO `tb_city` VALUES (275,'001024004','安顺','001024',24,'中国/贵州/安顺','市',3,'as','anshun','0853','561000');
INSERT INTO `tb_city` VALUES (276,'001024005','铜仁地','001024',24,'中国/贵州/铜仁地','区',3,'trd','tongrendi','0856','554300');
INSERT INTO `tb_city` VALUES (277,'001024006','毕节地','001024',24,'中国/贵州/毕节地','区',3,'bjd','bijiedi','0857','551700');
INSERT INTO `tb_city` VALUES (278,'001024007','黔西南','001024',24,'中国/贵州/黔西南','州',3,'qxn','qianxinan','0859','562400');
INSERT INTO `tb_city` VALUES (279,'001024008','黔东南','001024',24,'中国/贵州/黔东南','州',3,'qdn','qiandongnan','0855','556000');
INSERT INTO `tb_city` VALUES (280,'001024009','黔南','001024',24,'中国/贵州/黔南','州',3,'qn','qiannan','0854','558000');
INSERT INTO `tb_city` VALUES (281,'001025001','昆明','001025',25,'中国/云南/昆明','市',3,'km','kunming','0871','650011');
INSERT INTO `tb_city` VALUES (282,'001025002','曲靖','001025',25,'中国/云南/曲靖','市',3,'qj','qujing','0874','655000');
INSERT INTO `tb_city` VALUES (283,'001025003','玉溪','001025',25,'中国/云南/玉溪','市',3,'yx','yuxi','0877','653100');
INSERT INTO `tb_city` VALUES (284,'001025004','保山','001025',25,'中国/云南/保山','市',3,'bs','baoshan','0875','678000');
INSERT INTO `tb_city` VALUES (285,'001025005','昭通','001025',25,'中国/云南/昭通','市',3,'zt','zhaotong','0870','657000');
INSERT INTO `tb_city` VALUES (286,'001025006','思茅','001025',25,'中国/云南/思茅','地区',3,'smd','simaodi','0879','665000');
INSERT INTO `tb_city` VALUES (287,'001025007','临沧','001025',25,'中国/云南/临沧','地区',3,'lcd','lincangdi','0883','677000');
INSERT INTO `tb_city` VALUES (288,'001025008','丽江','001025',25,'中国/云南/丽江','市',3,'lj','lijiang','0888','674100');
INSERT INTO `tb_city` VALUES (289,'001025009','文山','001025',25,'中国/云南/文山','州',3,'ws','wenshan','0876','663000');
INSERT INTO `tb_city` VALUES (290,'001025010','红河','001025',25,'中国/云南/红河','州',3,'hh','honghe','0873','661400');
INSERT INTO `tb_city` VALUES (291,'001025011','西双版纳','001025',25,'中国/云南/西双版纳','州',3,'xsbn','xishuangban','0691','666100');
INSERT INTO `tb_city` VALUES (292,'001025012','楚雄','001025',25,'中国/云南/楚雄','州',3,'cx','chuxiong','0878','675000');
INSERT INTO `tb_city` VALUES (293,'001025013','大理','001025',25,'中国/云南/大理','州',3,'dl','dali','0872','671000');
INSERT INTO `tb_city` VALUES (294,'001025014','德宏','001025',25,'中国/云南/德宏','州',3,'dh','dehong','0692','678400');
INSERT INTO `tb_city` VALUES (295,'001025015','怒江','001025',25,'中国/云南/怒江','州',3,'nj','nujiang','0886','673100');
INSERT INTO `tb_city` VALUES (296,'001025016','迪庆','001025',25,'中国/云南/迪庆','州',3,'dq','diqing','0887','674400');
INSERT INTO `tb_city` VALUES (297,'001026001','拉萨','001026',26,'中国/西藏/拉萨','市',3,'ls','lasa','0891','850012');
INSERT INTO `tb_city` VALUES (298,'001026002','那曲','001026',26,'中国/西藏/那曲','地区',3,'nqd','naqudi','0896','852000');
INSERT INTO `tb_city` VALUES (299,'001026003','昌都','001026',26,'中国/西藏/昌都','地区',3,'cdd','changdudi','0895','854000');
INSERT INTO `tb_city` VALUES (300,'001026004','山南','001026',26,'中国/西藏/山南','地区',3,'snd','shannandi','0893','856000');
INSERT INTO `tb_city` VALUES (301,'001026005','日喀则','001026',26,'中国/西藏/日喀则','地区',3,'rkzd','rikazedi','0892','857000');
INSERT INTO `tb_city` VALUES (302,'001026006','阿里','001026',26,'中国/西藏/阿里','地区',3,'ald','alidi','0897','859000');
INSERT INTO `tb_city` VALUES (303,'001026007','林芝','001026',26,'中国/西藏/林芝','地区',3,'lzd','linzhidi','0894','860000');
INSERT INTO `tb_city` VALUES (304,'001027001','西安','001027',27,'中国/陕西/西安','市',3,'xa','xian','029','710003');
INSERT INTO `tb_city` VALUES (305,'001027002','铜川','001027',27,'中国/陕西/铜川','市',3,'tc','tongchuan','0919','727000');
INSERT INTO `tb_city` VALUES (306,'001027003','宝鸡','001027',27,'中国/陕西/宝鸡','市',3,'bj','baoji','0917','721000');
INSERT INTO `tb_city` VALUES (307,'001027004','咸阳','001027',27,'中国/陕西/咸阳','市',3,'xy','xianyang','0910','712000');
INSERT INTO `tb_city` VALUES (308,'001027005','渭南','001027',27,'中国/陕西/渭南','市',3,'wn','weinan','0913','714000');
INSERT INTO `tb_city` VALUES (309,'001027006','延安','001027',27,'中国/陕西/延安','市',3,'ya','yanan','0911','716000');
INSERT INTO `tb_city` VALUES (310,'001027007','汉中','001027',27,'中国/陕西/汉中','市',3,'hz','hanzhong','0916','723000');
INSERT INTO `tb_city` VALUES (311,'001027008','榆林','001027',27,'中国/陕西/榆林','市',3,'yl','yulin','0912','719000');
INSERT INTO `tb_city` VALUES (312,'001027009','安康','001027',27,'中国/陕西/安康','市',3,'ak','ankang','0915','725000');
INSERT INTO `tb_city` VALUES (313,'001027010','商洛','001027',27,'中国/陕西/商洛','市',3,'sl','shangluo','0914','726000');
INSERT INTO `tb_city` VALUES (314,'001028001','兰州','001028',28,'中国/甘肃/兰州','市',3,'lz','lanzhou','0931','730030');
INSERT INTO `tb_city` VALUES (315,'001028002','金昌','001028',28,'中国/甘肃/金昌','市',3,'jc','jinchang','0935','737100');
INSERT INTO `tb_city` VALUES (316,'001028003','白银','001028',28,'中国/甘肃/白银','市',3,'by','baiyin','0943','730900');
INSERT INTO `tb_city` VALUES (317,'001028004','天水','001028',28,'中国/甘肃/天水','市',3,'ts','tianshui','0938','741000');
INSERT INTO `tb_city` VALUES (318,'001028005','嘉峪关','001028',28,'中国/甘肃/嘉峪关','市',3,'jyg','jiayuguan','0937','735100');
INSERT INTO `tb_city` VALUES (319,'001028006','武威','001028',28,'中国/甘肃/武威','市',3,'ww','wuwei','0935','733000');
INSERT INTO `tb_city` VALUES (320,'001028007','张掖','001028',28,'中国/甘肃/张掖','市',3,'zy','zhangye','0936','734000');
INSERT INTO `tb_city` VALUES (321,'001028008','平凉','001028',28,'中国/甘肃/平凉','市',3,'pl','pingliang','0933','744000');
INSERT INTO `tb_city` VALUES (322,'001028009','酒泉','001028',28,'中国/甘肃/酒泉','市',3,'jq','jiuquan','0937','735000');
INSERT INTO `tb_city` VALUES (323,'001028010','庆阳','001028',28,'中国/甘肃/庆阳','市',3,'qy','qingyang','0934','745000');
INSERT INTO `tb_city` VALUES (324,'001028011','定西','001028',28,'中国/甘肃/定西','地区',3,'dxd','dingxidi','0932','743000');
INSERT INTO `tb_city` VALUES (325,'001028012','陇南','001028',28,'中国/甘肃/陇南','地区',3,'lnd','longnandi','0935','742500');
INSERT INTO `tb_city` VALUES (326,'001028013','甘南','001028',28,'中国/甘肃/甘南','州',3,'gn','gannan','0941','747004');
INSERT INTO `tb_city` VALUES (327,'001028014','临夏','001028',28,'中国/甘肃/临夏','州',3,'lx','linxia','0930','731100');
INSERT INTO `tb_city` VALUES (328,'001029001','西宁','001029',29,'中国/青海/西宁','市',3,'xn','xining','0971','810000');
INSERT INTO `tb_city` VALUES (329,'001029002','海东','001029',29,'中国/青海/海东','地区',3,'hdd','haidongdi','0972','810600');
INSERT INTO `tb_city` VALUES (330,'001029003','海北','001029',29,'中国/青海/海北','州',3,'hb','haibei','0970','812200');
INSERT INTO `tb_city` VALUES (331,'001029004','黄南','001029',29,'中国/青海/黄南','州',3,'hn','huangnan','0973','811300');
INSERT INTO `tb_city` VALUES (332,'001029005','海南','001029',29,'中国/青海/海南','州',3,'hn','hainan','0974','813000');
INSERT INTO `tb_city` VALUES (333,'001029006','果洛','001029',29,'中国/青海/果洛','州',3,'gl','guoluo','0975','814000');
INSERT INTO `tb_city` VALUES (334,'001029007','玉树','001029',29,'中国/青海/玉树','州',3,'ys','yushu','0976','815000');
INSERT INTO `tb_city` VALUES (335,'001029008','海西','001029',29,'中国/青海/海西','州',3,'hx','haixi','0977','817000');
INSERT INTO `tb_city` VALUES (336,'001030001','银川','001030',30,'中国/宁夏/银川','市',3,'yc','yinchuan','0951','750004');
INSERT INTO `tb_city` VALUES (337,'001030002','石嘴山','001030',30,'中国/宁夏/石嘴山','市',3,'szs','shizuishan','0952','753000');
INSERT INTO `tb_city` VALUES (338,'001030003','吴忠','001030',30,'中国/宁夏/吴忠','市',3,'wz','wuzhong','0953','751100');
INSERT INTO `tb_city` VALUES (339,'001030004','固原','001030',30,'中国/宁夏/固原','市',3,'gy','guyuan','0954','756000');
INSERT INTO `tb_city` VALUES (340,'001031001','乌鲁木齐','001031',31,'中国/新疆/乌鲁木齐','市',3,'wlmq','wulumuqi','0991','830002');
INSERT INTO `tb_city` VALUES (341,'001031002','克拉玛依','001031',31,'中国/新疆/克拉玛依','市',3,'klmy','kelamayi','0990','834000');
INSERT INTO `tb_city` VALUES (342,'001031003','直辖行政单位','001031',31,'中国/新疆/直辖行政单位','null',3,'zxxzdw','zhixiaxingz','0993','832000');
INSERT INTO `tb_city` VALUES (343,'001031004','吐鲁番','001031',31,'中国/新疆/吐鲁番','地区',3,'tlfd','tulufandi','0995','838000');
INSERT INTO `tb_city` VALUES (344,'001031005','哈密','001031',31,'中国/新疆/哈密','地区',3,'hmd','hamidi','0902','839000');
INSERT INTO `tb_city` VALUES (345,'001031006','和田','001031',31,'中国/新疆/和田','地区',3,'htd','hetiandi','0903','848000');
INSERT INTO `tb_city` VALUES (346,'001031007','阿克苏','001031',31,'中国/新疆/阿克苏','地区',3,'aksd','akesudi','0997','843000');
INSERT INTO `tb_city` VALUES (347,'001031008','喀什','001031',31,'中国/新疆/喀什','地区',3,'ksd','kashidi','0998','844000');
INSERT INTO `tb_city` VALUES (348,'001031009','克孜勒苏','001031',31,'中国/新疆/克孜勒苏','州',3,'kzls','kezilesu','0908','845350');
INSERT INTO `tb_city` VALUES (349,'001031010','巴音郭楞','001031',31,'中国/新疆/巴音郭楞','州',3,'bygl','bayinguolen','0996','841000');
INSERT INTO `tb_city` VALUES (350,'001031011','昌吉','001031',31,'中国/新疆/昌吉','州',3,'cj','changji','0994','831100');
INSERT INTO `tb_city` VALUES (351,'001031012','博尔塔拉','001031',31,'中国/新疆/博尔塔拉','州',3,'betl','boertala','0909','833400');
INSERT INTO `tb_city` VALUES (352,'001031013','伊犁','001031',31,'中国/新疆/伊犁','州',3,'yl','yili','0999','835000');
INSERT INTO `tb_city` VALUES (353,'001031014','塔城','001031',31,'中国/新疆/塔城','地区',3,'tcd','tachengdi','0901','834700');
INSERT INTO `tb_city` VALUES (354,'001031015','阿勒泰','001031',31,'中国/新疆/阿勒泰','地区',3,'altd','aletaidi','0906','836500');
INSERT INTO `tb_city` VALUES (355,'001009001','上海','001009',9,'中国/上海/市辖区','null',3,'null','null','020','200000');
INSERT INTO `tb_city` VALUES (358,'001022002','重庆','001022',22,'中国/重庆/市','null',3,'null','null','null','null');
INSERT INTO `tb_city` VALUES (360,'001002001','天津','001002',2,'中国/天津/市','null',3,'null','null','null','null');
/*!40000 ALTER TABLE `tb_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_download_category`
--

DROP TABLE IF EXISTS `tb_download_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_download_category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `seq` varchar(11) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_download_category`
--

LOCK TABLES `tb_download_category` WRITE;
/*!40000 ALTER TABLE `tb_download_category` DISABLE KEYS */;
INSERT INTO `tb_download_category` VALUES (1,'aaaa','2','D',1,'2014-08-12 21:26:18',1,'2014-08-17 12:53:02');
INSERT INTO `tb_download_category` VALUES (2,'PALACOS','1','D',1,'2014-08-13 00:39:46',1,'2014-08-13 00:43:58');
INSERT INTO `tb_download_category` VALUES (3,'aaa','0','D',1,'2014-08-13 23:10:55',1,'2014-08-17 12:29:32');
INSERT INTO `tb_download_category` VALUES (4,'PALACOS 关节骨水泥','1','A',1,'2014-08-17 12:42:57',1,'2014-11-28 14:17:33');
INSERT INTO `tb_download_category` VALUES (5,'Osteopal V 脊柱骨水泥','2','A',1,'2014-08-17 12:44:51',1,'2014-11-28 12:35:55');
INSERT INTO `tb_download_category` VALUES (6,'骨水泥真空混合系统','3','D',1,'2014-08-17 12:46:16',1,'2014-11-28 14:07:19');
INSERT INTO `tb_download_category` VALUES (7,'MAST 聚乳酸手术保护膜','3','A',1,'2014-08-17 12:46:59',1,'2014-11-28 14:08:39');
INSERT INTO `tb_download_category` VALUES (8,'no','0','D',1,'2014-11-03 16:10:28',1,'2014-11-03 23:04:41');
INSERT INTO `tb_download_category` VALUES (9,'aa','aa','D',1,'2014-11-27 23:33:16',1,'2014-11-27 23:35:34');
/*!40000 ALTER TABLE `tb_download_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_download_file`
--

DROP TABLE IF EXISTS `tb_download_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_download_file` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `length` int(11) NOT NULL,
  `seq` varchar(11) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  `extlink` varchar(145) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_download_file`
--

LOCK TABLES `tb_download_file` WRITE;
/*!40000 ALTER TABLE `tb_download_file` DISABLE KEYS */;
INSERT INTO `tb_download_file` VALUES (1,-1,'','',0,'0','D',1,'2014-08-12 02:28:29',1,'2014-08-13 00:37:21',NULL);
INSERT INTO `tb_download_file` VALUES (2,-1,'','',0,'0','A',1,'2014-08-12 02:29:12',1,'2014-08-12 02:29:12',NULL);
INSERT INTO `tb_download_file` VALUES (3,-1,'','',0,'0','A',1,'2014-08-12 21:12:55',1,'2014-08-12 21:12:55',NULL);
INSERT INTO `tb_download_file` VALUES (4,-1,'','',0,'0','A',1,'2014-08-12 21:15:49',1,'2014-08-12 21:15:49',NULL);
INSERT INTO `tb_download_file` VALUES (5,-1,'','',0,'0','A',1,'2014-08-12 21:17:29',1,'2014-08-12 21:17:29',NULL);
INSERT INTO `tb_download_file` VALUES (6,-1,'aaaa','14081300023banner1.png',6682,'1','A',1,'2014-08-12 21:26:13',1,'2014-08-13 00:34:39',NULL);
INSERT INTO `tb_download_file` VALUES (7,-1,'','',0,'0','A',1,'2014-08-12 21:44:12',1,'2014-08-12 21:44:12',NULL);
INSERT INTO `tb_download_file` VALUES (8,-1,'','',0,'0','A',1,'2014-08-12 21:44:13',1,'2014-08-12 21:44:13',NULL);
INSERT INTO `tb_download_file` VALUES (9,-1,'','',0,'0','A',1,'2014-08-12 21:44:13',1,'2014-08-12 21:44:13',NULL);
INSERT INTO `tb_download_file` VALUES (10,-1,'','',0,'0','A',1,'2014-08-12 21:44:14',1,'2014-08-12 21:44:14',NULL);
INSERT INTO `tb_download_file` VALUES (11,-1,'','',0,'0','A',1,'2014-08-12 21:46:43',1,'2014-08-12 21:46:43',NULL);
INSERT INTO `tb_download_file` VALUES (12,-1,'','',0,'0','A',1,'2014-08-12 21:46:45',1,'2014-08-12 21:46:45',NULL);
INSERT INTO `tb_download_file` VALUES (13,-1,'','',0,'0','A',1,'2014-08-12 21:46:47',1,'2014-08-12 21:46:47',NULL);
INSERT INTO `tb_download_file` VALUES (14,-1,'','',0,'0','A',1,'2014-08-12 21:46:48',1,'2014-08-12 21:46:48',NULL);
INSERT INTO `tb_download_file` VALUES (15,-1,'','',0,'0','A',1,'2014-08-12 21:58:00',1,'2014-08-12 21:58:00',NULL);
INSERT INTO `tb_download_file` VALUES (16,-1,'','',0,'0','A',1,'2014-08-12 22:02:30',1,'2014-08-12 22:02:30',NULL);
INSERT INTO `tb_download_file` VALUES (17,-1,'','',0,'0','A',1,'2014-08-12 22:02:30',1,'2014-08-12 22:02:30',NULL);
INSERT INTO `tb_download_file` VALUES (18,-1,'','',0,'0','A',1,'2014-08-12 22:02:46',1,'2014-08-12 22:02:46',NULL);
INSERT INTO `tb_download_file` VALUES (19,-1,'','',0,'0','A',1,'2014-08-12 22:06:25',1,'2014-08-12 22:06:25',NULL);
INSERT INTO `tb_download_file` VALUES (20,-1,'','',0,'0','A',1,'2014-08-12 22:38:34',1,'2014-08-12 22:38:34',NULL);
INSERT INTO `tb_download_file` VALUES (21,-1,'','',0,'0','A',1,'2014-08-12 22:43:00',1,'2014-08-12 22:43:00',NULL);
INSERT INTO `tb_download_file` VALUES (22,-1,'','',0,'0','A',1,'2014-08-12 22:51:58',1,'2014-08-12 22:51:58',NULL);
INSERT INTO `tb_download_file` VALUES (23,-1,'','',0,'0','A',1,'2014-08-12 23:16:24',1,'2014-08-12 23:16:24',NULL);
INSERT INTO `tb_download_file` VALUES (24,-1,'','',0,'0','A',1,'2014-08-12 23:41:18',1,'2014-08-12 23:41:18',NULL);
INSERT INTO `tb_download_file` VALUES (25,-1,'','',0,'0','A',1,'2014-08-13 00:04:52',1,'2014-08-13 00:04:52',NULL);
INSERT INTO `tb_download_file` VALUES (26,-1,'','',0,'0','A',1,'2014-08-13 00:04:52',1,'2014-08-13 00:04:52',NULL);
INSERT INTO `tb_download_file` VALUES (27,-1,'','',0,'0','A',1,'2014-08-13 00:04:53',1,'2014-08-13 00:04:53',NULL);
INSERT INTO `tb_download_file` VALUES (28,-1,'','',0,'0','A',1,'2014-08-13 00:04:53',1,'2014-08-13 00:04:53',NULL);
INSERT INTO `tb_download_file` VALUES (29,-1,'','',0,'0','A',1,'2014-08-13 00:08:00',1,'2014-08-13 00:08:00',NULL);
INSERT INTO `tb_download_file` VALUES (30,-1,'','',0,'0','A',1,'2014-08-13 00:08:01',1,'2014-08-13 00:08:01',NULL);
INSERT INTO `tb_download_file` VALUES (31,-1,'','',0,'0','A',1,'2014-08-13 00:08:02',1,'2014-08-13 00:08:02',NULL);
INSERT INTO `tb_download_file` VALUES (32,-1,'','',0,'0','A',1,'2014-08-13 00:08:02',1,'2014-08-13 00:08:02',NULL);
INSERT INTO `tb_download_file` VALUES (33,-1,'','',0,'0','A',1,'2014-08-13 00:08:23',1,'2014-08-13 00:08:23',NULL);
INSERT INTO `tb_download_file` VALUES (34,-1,'','',0,'0','A',1,'2014-08-13 00:08:24',1,'2014-08-13 00:08:24',NULL);
INSERT INTO `tb_download_file` VALUES (35,-1,'','',0,'0','A',1,'2014-08-13 00:08:24',1,'2014-08-13 00:08:24',NULL);
INSERT INTO `tb_download_file` VALUES (36,-1,'','',0,'0','A',1,'2014-08-13 00:08:25',1,'2014-08-13 00:08:25',NULL);
INSERT INTO `tb_download_file` VALUES (37,-1,'','',0,'0','A',1,'2014-08-13 00:12:37',1,'2014-08-13 00:12:37',NULL);
INSERT INTO `tb_download_file` VALUES (38,-1,'','',0,'0','A',1,'2014-08-13 00:13:13',1,'2014-08-13 00:13:13',NULL);
INSERT INTO `tb_download_file` VALUES (39,-1,'','',0,'0','A',1,'2014-08-13 00:20:44',1,'2014-08-13 00:20:44',NULL);
INSERT INTO `tb_download_file` VALUES (40,-1,'','',0,'0','A',1,'2014-08-13 00:20:45',1,'2014-08-13 00:20:45',NULL);
INSERT INTO `tb_download_file` VALUES (41,-1,'','',0,'0','A',1,'2014-08-13 00:20:45',1,'2014-08-13 00:20:45',NULL);
INSERT INTO `tb_download_file` VALUES (42,-1,'','',0,'0','A',1,'2014-08-13 00:20:46',1,'2014-08-13 00:20:46',NULL);
INSERT INTO `tb_download_file` VALUES (43,-1,'','',0,'0','A',1,'2014-08-13 00:21:15',1,'2014-08-13 00:21:15',NULL);
INSERT INTO `tb_download_file` VALUES (44,-1,'','',0,'0','A',1,'2014-08-13 00:23:18',1,'2014-08-13 00:23:18',NULL);
INSERT INTO `tb_download_file` VALUES (45,-1,'','',0,'0','A',1,'2014-08-13 00:23:33',1,'2014-08-13 00:23:33',NULL);
INSERT INTO `tb_download_file` VALUES (46,-1,'','',0,'0','A',1,'2014-08-13 00:26:55',1,'2014-08-13 00:26:55',NULL);
INSERT INTO `tb_download_file` VALUES (47,-1,'eee','14081300003banner1.png',6682,'0','A',1,'2014-08-13 00:27:01',1,'2014-08-13 00:34:39',NULL);
INSERT INTO `tb_download_file` VALUES (48,-1,'ccc','14081300011logo1.png',4380,'0','I',1,'2014-08-13 00:27:07',1,'2014-08-13 00:34:39',NULL);
INSERT INTO `tb_download_file` VALUES (49,-1,'aaa','14081300018banner2.png',8772,'0','A',1,'2014-08-13 00:27:14',1,'2014-08-13 00:34:39',NULL);
INSERT INTO `tb_download_file` VALUES (50,-1,'','',0,'0','A',1,'2014-08-13 00:38:58',1,'2014-08-13 00:38:58',NULL);
INSERT INTO `tb_download_file` VALUES (51,-1,'aaa','14081300024banner1.png',6682,'0','A',1,'2014-08-13 00:39:20',1,'2014-08-13 00:43:38',NULL);
INSERT INTO `tb_download_file` VALUES (52,-1,'bbb','14081300034banner2.png',8772,'0','A',1,'2014-08-13 00:39:27',1,'2014-08-13 00:43:38',NULL);
INSERT INTO `tb_download_file` VALUES (53,-1,'ccc','14081300042ico.png',818,'0','A',1,'2014-08-13 00:39:38',1,'2014-08-13 00:43:38',NULL);
INSERT INTO `tb_download_file` VALUES (54,3,'aa','0',0,'0','A',1,'2014-08-13 23:10:51',1,'2014-08-13 23:10:55',NULL);
INSERT INTO `tb_download_file` VALUES (55,3,'ee','0',0,'0','A',1,'2014-08-13 23:10:52',1,'2014-08-13 23:10:55',NULL);
INSERT INTO `tb_download_file` VALUES (56,3,'cc','0',0,'0','A',1,'2014-08-13 23:10:54',1,'2014-08-13 23:10:55',NULL);
INSERT INTO `tb_download_file` VALUES (57,-4,'PALACOS 彩页','14081712036PALACOS_Family_Folder.pdf',7173027,'0','A',1,'2014-08-17 12:30:12',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (58,-4,'PALACOS 骨水泥','14081712020PALACOS_LV_IFU_CN.pdf',1856772,'0','A',1,'2014-08-17 12:33:18',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (59,-4,'PALACOS 抗生素骨水泥','14081712024PALACOS_LVG_IFU_CN.pdf',1913394,'0','A',1,'2014-08-17 12:40:04',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (60,-4,'三代骨水泥技术','14081712002PALACOS_MV_IFU_CN.pdf',2975578,'0','A',1,'2014-08-17 12:40:44',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (61,-4,'Palacos MVG 简介','14081712017PALACOS_MVG_IFU_CN.pdf',3043303,'0','I',1,'2014-08-17 12:41:10',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (62,-4,'Palacos R 简介','14081712036PALACOS_R_IFU_CN.pdf',3014546,'0','I',1,'2014-08-17 12:41:25',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (63,-4,'Palacos RG 简介','14081712003PALACOS_RG_IFU_CN.pdf',1885597,'0','I',1,'2014-08-17 12:41:40',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (64,-4,'Palacos 附件','14081712024PALACOS_Primary_Accessories_Folder_UK.pdf',2007346,'0','I',1,'2014-08-17 12:42:07',1,'2014-11-27 14:50:46',NULL);
INSERT INTO `tb_download_file` VALUES (65,-1,'','',0,'0','A',1,'2014-08-17 12:42:33',1,'2014-08-17 12:42:33',NULL);
INSERT INTO `tb_download_file` VALUES (66,1,'Osteopal V 简介','14081712042PRINT_Osteopal.pdf',10503819,'0','A',1,'2014-08-17 12:44:02',1,'2014-08-17 12:52:31',NULL);
INSERT INTO `tb_download_file` VALUES (67,6,'PALAMIX 简介','14081712022PALAMIX_Folder_CN.pdf',9809571,'0','A',1,'2014-08-17 12:45:04',1,'2014-11-27 14:58:05',NULL);
INSERT INTO `tb_download_file` VALUES (68,6,'PALAMIX 使用说明书','14081712059PALAMIX_Guideline_CN_PRINT.pdf',10285096,'0','A',1,'2014-08-17 12:45:32',1,'2014-11-27 14:58:05',NULL);
INSERT INTO `tb_download_file` VALUES (69,-7,'','0',0,'0','A',1,'2014-08-17 12:46:56',1,'2014-08-17 12:58:47',NULL);
INSERT INTO `tb_download_file` VALUES (70,-5,'Osteopal V 简介','14081712012PRINT_Osteopal.pdf',10503819,'0','A',1,'2014-08-17 12:58:07',1,'2014-08-17 12:58:34',NULL);
INSERT INTO `tb_download_file` VALUES (71,-1,'','',0,'0','A',1,'2014-08-24 14:39:57',1,'2014-08-24 14:39:57',NULL);
INSERT INTO `tb_download_file` VALUES (72,8,'','14110316026膝关节粘连松解术.png',29320,'0','A',1,'2014-11-03 16:10:20',1,'2014-11-03 16:10:28',NULL);
INSERT INTO `tb_download_file` VALUES (73,-1,'','',0,'0','A',1,'2014-11-27 14:45:33',1,'2014-11-27 14:45:33',NULL);
INSERT INTO `tb_download_file` VALUES (74,-1,'','',0,'0','A',1,'2014-11-27 14:52:17',1,'2014-11-27 14:52:17',NULL);
INSERT INTO `tb_download_file` VALUES (75,-1,'','',0,'0','A',1,'2014-11-27 14:53:18',1,'2014-11-27 14:53:18',NULL);
INSERT INTO `tb_download_file` VALUES (76,-1,'','',0,'0','A',1,'2014-11-27 14:53:31',1,'2014-11-27 14:53:31',NULL);
INSERT INTO `tb_download_file` VALUES (77,-1,'','',0,'0','A',1,'2014-11-27 14:57:15',1,'2014-11-27 14:57:15',NULL);
INSERT INTO `tb_download_file` VALUES (78,-1,'','',0,'0','A',1,'2014-11-27 14:57:47',1,'2014-11-27 14:57:47',NULL);
INSERT INTO `tb_download_file` VALUES (79,-1,'','',0,'0','A',1,'2014-11-27 14:59:48',1,'2014-11-27 14:59:48',NULL);
INSERT INTO `tb_download_file` VALUES (80,-1,'','',0,'0','A',1,'2014-11-27 15:00:42',1,'2014-11-27 15:00:42',NULL);
INSERT INTO `tb_download_file` VALUES (81,-1,'','',0,'0','A',1,'2014-11-27 15:00:49',1,'2014-11-27 15:00:49',NULL);
INSERT INTO `tb_download_file` VALUES (82,9,'aaa','0',0,'0','A',1,'2014-11-27 23:32:55',1,'2014-11-27 23:35:21','http://www.baidu.com/img/bd_logo1.png');
INSERT INTO `tb_download_file` VALUES (83,-1,'','',0,'0','A',1,'2014-11-28 10:16:48',1,'2014-11-28 10:16:48','');
INSERT INTO `tb_download_file` VALUES (84,-1,'','',0,'0','A',1,'2014-11-28 10:17:15',1,'2014-11-28 10:17:15','');
INSERT INTO `tb_download_file` VALUES (85,-1,'','',0,'0','A',1,'2014-11-28 10:17:17',1,'2014-11-28 10:17:17','');
INSERT INTO `tb_download_file` VALUES (86,5,'OSTEOPAL V 彩页','0',0,'0','A',1,'2014-11-28 12:35:07',1,'2014-11-28 12:35:55','http://pan.baidu.com/s/1gd28rWv');
INSERT INTO `tb_download_file` VALUES (87,5,'OSTEOPAL V 电子书','0',0,'0','A',1,'2014-11-28 12:35:31',1,'2014-11-28 12:35:55','http://pan.baidu.com/s/1ntiJrW9');
INSERT INTO `tb_download_file` VALUES (88,4,'PALACOS 彩页','0',0,'0','A',1,'2014-11-28 14:04:06',1,'2014-11-28 14:17:33','http://pan.baidu.com/s/1dDkv3YL');
INSERT INTO `tb_download_file` VALUES (89,4,'骨水泥电子书','0',0,'0','A',1,'2014-11-28 14:04:30',1,'2014-11-28 14:17:33','http://pan.baidu.com/s/1hqxgAES');
INSERT INTO `tb_download_file` VALUES (90,4,'抗生素骨水泥电子书','0',0,'0','A',1,'2014-11-28 14:04:51',1,'2014-11-28 14:17:33','http://pan.baidu.com/s/1sj0Sdop');
INSERT INTO `tb_download_file` VALUES (91,4,'三代骨水泥技术电子书','0',0,'0','A',1,'2014-11-28 14:05:09',1,'2014-11-28 14:17:33','http://pan.baidu.com/s/1eQ1o1Ho');
INSERT INTO `tb_download_file` VALUES (92,7,'SurgiWrap 彩页','0',0,'0','A',1,'2014-11-28 14:07:58',1,'2014-11-28 14:08:39','http://pan.baidu.com/s/1c0gZL9e');
INSERT INTO `tb_download_file` VALUES (93,7,'SurgiWrap 电子书','0',0,'0','A',1,'2014-11-28 14:08:17',1,'2014-11-28 14:08:39','http://pan.baidu.com/s/1kTMIXF5');
/*!40000 ALTER TABLE `tb_download_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_function`
--

DROP TABLE IF EXISTS `tb_function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_function` (
  `function_id` int(11) NOT NULL,
  `function_name` varchar(50) NOT NULL,
  `function_link` varchar(100) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `function_type` int(11) NOT NULL,
  `function_group` int(11) NOT NULL,
  `seq` int(11) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`function_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_function`
--

LOCK TABLES `tb_function` WRITE;
/*!40000 ALTER TABLE `tb_function` DISABLE KEYS */;
INSERT INTO `tb_function` VALUES (1,'内容管理','#',1,1,1,1,'A');
INSERT INTO `tb_function` VALUES (2,'一般内容','general.php',1,9,1,11,'A');
INSERT INTO `tb_function` VALUES (3,'下载中心','download.php',1,9,1,12,'A');
INSERT INTO `tb_function` VALUES (4,'新闻中心','news.php',1,9,1,13,'A');
INSERT INTO `tb_function` VALUES (5,'伙伴管理','#',5,1,1,14,'A');
INSERT INTO `tb_function` VALUES (6,'分区经理','manager.php',5,9,1,15,'A');
INSERT INTO `tb_function` VALUES (7,'日常管理','#',7,1,2,2,'A');
INSERT INTO `tb_function` VALUES (8,'用户管理','user.php',7,9,7,71,'A');
INSERT INTO `tb_function` VALUES (9,'网站管理','website.php',7,9,7,72,'A');
INSERT INTO `tb_function` VALUES (10,'供应商管理','partner.php',5,9,1,15,'A');
INSERT INTO `tb_function` VALUES (11,'产品分类管理','product_category.php',1,9,1,16,'A');
INSERT INTO `tb_function` VALUES (12,'产品管理','product.php',1,9,1,17,'A');
INSERT INTO `tb_function` VALUES (13,'加盟申请','requisition.php',5,9,1,16,'A');
/*!40000 ALTER TABLE `tb_function` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_function_right`
--

DROP TABLE IF EXISTS `tb_function_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_function_right` (
  `function_id` int(11) NOT NULL,
  `right_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_function_right`
--

LOCK TABLES `tb_function_right` WRITE;
/*!40000 ALTER TABLE `tb_function_right` DISABLE KEYS */;
INSERT INTO `tb_function_right` VALUES (2,2,1);
INSERT INTO `tb_function_right` VALUES (3,2,2);
INSERT INTO `tb_function_right` VALUES (3,3,3);
INSERT INTO `tb_function_right` VALUES (4,2,4);
INSERT INTO `tb_function_right` VALUES (4,3,5);
INSERT INTO `tb_function_right` VALUES (10,2,6);
INSERT INTO `tb_function_right` VALUES (10,3,7);
INSERT INTO `tb_function_right` VALUES (6,2,8);
INSERT INTO `tb_function_right` VALUES (6,3,9);
INSERT INTO `tb_function_right` VALUES (8,2,10);
INSERT INTO `tb_function_right` VALUES (9,2,11);
INSERT INTO `tb_function_right` VALUES (9,3,12);
INSERT INTO `tb_function_right` VALUES (11,2,13);
INSERT INTO `tb_function_right` VALUES (11,3,14);
INSERT INTO `tb_function_right` VALUES (12,2,15);
INSERT INTO `tb_function_right` VALUES (12,3,16);
INSERT INTO `tb_function_right` VALUES (13,2,18);
/*!40000 ALTER TABLE `tb_function_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_general`
--

DROP TABLE IF EXISTS `tb_general`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_general` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `content` text,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_general`
--

LOCK TABLES `tb_general` WRITE;
/*!40000 ALTER TABLE `tb_general` DISABLE KEYS */;
INSERT INTO `tb_general` VALUES (1,'company_descript','关于我们','关于我们的介绍','string','本公司为德国Heraeus Medical医疗器械生产商在中国大陆指定产品的总代理，同时作为企业驻中国的联络处。\n\n公司拥有稳定成熟的产品销售市场，经营的产品为同领域中的优秀产品，公司负责德国骨水泥产品在大陆地区的渠道销售管理及市场技术支持服务。为快速完成德国生产商对渠道规范的要求，也更符合国内市场的需求！\n',1,'2014-09-01 22:00:50');
INSERT INTO `tb_general` VALUES (2,'contact_us_company','联系我们公司信息','联系我们顶部','string','<div class=\"span7\">\n							<h4>雷德睦华医药科技（北京）有限公司北京总部</h4>\n							<p>\n							<strong><i class=\"icon-home\"></i>地址 :</strong><br>\n							北京市丰台区马家堡东路106号自然新天地写字楼606室<br>\n							邮编：100068\n							</p>\n							<p>\n							<strong><i class=\"icon-phone\"></i>北京 联系电话 :</strong><br>\n							010-58031636<br>\n							010-58032661<br>\n							传真：010-58031636 转 804\n							</p>	\n							<p>\n							<strong><i class=\"icon-phone\"></i>上海 联系电话 :</strong><br>\n							021-60908582<br>\n							传真：021-60908583\n							</p>							\n						</div>\n						<div class=\"span5\">\n							<h4>&nbsp;</h4>\n							<p>\n							<strong><h6><i class=\"icon-globe\"></i>微信关注</h6></strong>\n							<img alt=\"微信\" style=\"height:185px\" src=\"/themes/lm/images/qrcode.png\" />\n							</p>\n						</div>',1,'2014-11-27 23:50:16');
/*!40000 ALTER TABLE `tb_general` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_manager`
--

DROP TABLE IF EXISTS `tb_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_manager` (
  `id` int(11) NOT NULL,
  `chname` varchar(200) NOT NULL,
  `engname` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `tel` varchar(200) NOT NULL,
  `qq` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `provinces` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_manager`
--

LOCK TABLES `tb_manager` WRITE;
/*!40000 ALTER TABLE `tb_manager` DISABLE KEYS */;
INSERT INTO `tb_manager` VALUES (1,'蔡笋','steve','开发','13751082562','359304951','alucard263096@126.com','广东省深圳市龙岗区怡龙枫景园1栋A座201','Hubei,Guangdong','','','D',1,'2014-08-16 12:18:03',1,'2014-08-16 12:29:08');
INSERT INTO `tb_manager` VALUES (2,'啊啊啊','','开','1111','','','','Beijing,Tianjin,Hebei,Shaanxi,Mongol,Liaoning,Jilin,Heilongjian,Shanghai,Jiangsu,Zhejiang,Shandong,Henan,Hubei,Hunan,Guangdong,Guangxi,Hainan,Chongqing,Sichuan,Guizhou,Yunnan,Xizang,Qinghai,Ningxia,Xinjiang,Xianggang,Aomen,Taiwan','','','D',1,'2014-08-16 12:28:54',1,'2014-08-16 12:29:08');
INSERT INTO `tb_manager` VALUES (3,'vvvvv','','aaaaa','1123','','','','Xianggang','','','D',1,'2014-08-16 13:22:23',1,'2014-08-17 14:30:07');
INSERT INTO `tb_manager` VALUES (4,'周凯歌','Joseph','','18802131899','','','上海市虹口区新市路242号113室','Shanghai,Jiangsu,Zhejiang','','','A',1,'2014-08-17 14:29:52',1,'2014-11-20 16:42:02');
INSERT INTO `tb_manager` VALUES (5,'李春娟','Julie','','13607447390','','','湖南省长沙市湘江世纪城瑞江苑3栋2单元1306室','Hunan','','','A',1,'2014-08-17 14:30:50',1,'2014-08-17 14:31:01');
INSERT INTO `tb_manager` VALUES (6,'周瑞卿','Ricky','','13707145916','','','武汉市武昌区张之洞路280号欣隆紫苑A-1005室','Anhui,Jiangxi,Hubei,Hunan','','','A',1,'2014-08-17 14:31:48',1,'2014-11-20 16:43:38');
INSERT INTO `tb_manager` VALUES (7,'袁源宏','Kathy','','13980806340','','','四川省成都市成华区建设路53号国光一环大厦1808室','Chongqing,Sichuan,Guizhou,Yunnan','','','A',1,'2014-08-17 14:32:29',1,'2014-09-28 16:53:22');
INSERT INTO `tb_manager` VALUES (8,'胡慧霞','Angel','','13639929520','','','新疆乌鲁木齐市高新区桂林路92号万泰怡郡小区2号楼17H','Gansu,Xinjiang','','','A',1,'2014-08-17 14:33:00',1,'2014-11-20 16:56:10');
INSERT INTO `tb_manager` VALUES (9,'张孝杰','Mark','','18603701235','','','河南省郑州市商城路与英协路交叉口西200米滨河绿苑5号楼3单元10层1001室 ','Hebei,Shaanxi,Henan,Shanxi','','','A',1,'2014-08-17 14:33:54',1,'2014-08-17 14:33:54');
INSERT INTO `tb_manager` VALUES (10,'赵绍嵩','','','13837145808','','','石家庄市桥东区中山路与休门街汇翠家园2号楼3单元2001室','Hebei,Mongol','','','A',1,'2014-08-17 14:34:11',1,'2014-11-24 11:13:55');
INSERT INTO `tb_manager` VALUES (11,'侯彦杰','','','13991845726','','','西安市雁塔区电子正街凯悦华庭1602室','Shanxi,Qinghai,Ningxia','','','A',1,'2014-08-17 14:34:43',1,'2014-11-20 16:58:02');
INSERT INTO `tb_manager` VALUES (12,'张敬','Jessica','','18660795600','','','山东省济南市天桥区重汽翡翠郡北区7号楼1单元201室','Shandong','','','A',1,'2014-08-17 14:35:20',1,'2014-08-17 14:35:20');
INSERT INTO `tb_manager` VALUES (13,'饶小平','','','18870071616','','','江西省南昌市青山湖区学院路156号学院名都2栋3单元702室','Jiangxi','','','A',1,'2014-08-17 14:35:45',1,'2014-08-17 14:35:45');
INSERT INTO `tb_manager` VALUES (14,'黄逸','','','13922160737','','','广州市番禺区大石洛溪新城洛涛居7幢之一308室','Fujian,Guangdong,Guangxi,Hainan','','','A',1,'2014-08-17 14:36:34',1,'2014-09-28 16:53:51');
INSERT INTO `tb_manager` VALUES (15,'张婷','Tina','','15331988207','','','哈尔滨市南岗区宣化街、理治街，天马大厦（金丰·优豪斯）1单元2402室','Liaoning,Jilin,Heilongjiang','','','A',1,'2014-08-17 14:37:02',1,'2014-08-17 15:37:23');
INSERT INTO `tb_manager` VALUES (16,'王一然','Eleana','无','13601225883','','','','Beijing,Tianjin','','','A',1,'2014-11-20 17:07:03',1,'2014-11-20 17:07:03');
/*!40000 ALTER TABLE `tb_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_news`
--

DROP TABLE IF EXISTS `tb_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_news` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `summary` varchar(1000) NOT NULL,
  `published_date` date NOT NULL,
  `content` text,
  `viewcount` int(11) DEFAULT '0',
  `status` char(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_news`
--

LOCK TABLES `tb_news` WRITE;
/*!40000 ALTER TABLE `tb_news` DISABLE KEYS */;
INSERT INTO `tb_news` VALUES (1,'山西7名省级高官被查 三个月4次表态拥护反腐','山西被查的省级高官达7人并出现十八大以来首个“女大老虎” 晋仨月4次表态拥护反腐','2014-08-31','<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月29日，中纪委集中通报了山西省常委、统战部部长白云与山西省副省长任润厚被查，据法晚记者梳理，十八大以来被查的省部级及以上官员升至43人。山西被查的省部级高官已达7人，其中包括5名在任省委常委。白云成为十八大以来首个落马“女大老虎”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;昨天，山西省委、省政府就此做出表态：坚决拥护中央决定。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;据法晚记者梳理发现，山西省委在三个月内，共有4次表态。其中，在6月21日、8月24日、8月31日，《山西日报》均在一版头条的位置刊发了对涉嫌违纪违法被调查的表态。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;在《山西日报》报道的4次表态中，有3次被安排在头版头条的位置，从左到右分别为8月31日、8月24日、6月21日的版面 《山西日报》版面截图\n</p>\n<p style=\"font-size:14px;\">\n	<strong>&emsp;&emsp;仨月四次表态 最快几个小时</strong>\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;在山西，6月19日起，中央纪委网站通报两名山西“大老虎”落马——该省委常委、副省长杜善学，山西省政协副主席令政策后，山西省政府表态：坚决拥护中央决定。在将近3个月内，共有4次类似的表态，表态都在中纪委公布该省高官落马之后。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;法晚记者梳理几次表态的时间发现，山西省政府表态最快的在几个小时内，最长也不会超过24个小时。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;比如，最快的一次是在8月23日，当天上午中纪委发布消息，称山西省委常委、秘书长聂春玉，山西省委常委、太原市委书记陈川平涉嫌严重违纪违法被查。没过几个小时山西省委常委会就此事召开会议，表示坚决拥护中央决定。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月29日和6月19日，中央纪委网站通报山西“大老虎”落马后，其第二天召开会议，表示坚决拥护中央决定。\n</p>\n<p style=\"font-size:14px;\">\n	<strong>&emsp;&emsp;表态内容 坚决拥护并积极配合</strong>\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;在4次表态中，“坚决拥护”和“积极配合”的使用频率最高，在4次表态中均有出现。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;昨日，山西省委表态，坚决拥护中央决定，自觉在思想上、政治上、行动上与以习近平同志为总书记的党中央保持高度一致，积极配合中央纪委搞好案件调查工作。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;6月20日召开了山西省委常委(扩大)会议和省政府党组(扩大)会议。与会领导班子均表示，坚决拥护中央决定，将与党中央保持高度一致，积极配合中央纪委做好调查工作。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;在语气方面，也有变化，在6月20日的会议上强调，党员领导干部要“抵制各种不良诱惑，管好自己、家属和身边工作人员”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;而在昨日的会议上则表示，“无论什么人、什么地方出现腐败现象和腐败分子，都要坚决反对、坚决清除。”\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;除了落马后表态外，7月25日，中央纪委监察部网站发布题为《积极配合中央纪委调查组开展案件查办》的文章，作者标注为山西省纪委。“积极配合中央纪委调查组开展案件查办和有关协调工作”被列为重点工作之一。\n</p>\n<p style=\"font-size:14px;\">\n	<strong>&emsp;&emsp;三次省委表态为《山西日报》头版头条</strong>\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;记者从此前《山西日报》的报道中发现，6月19日，山西省省委常委、副省长杜善学，省政协副主席令政策被查，第二天上午即召开山西省委常委会(扩大)会议，该会由省委书记袁纯清主持。《山西日报》6月21日做了报道，并将报道安排在了一版头条的位置。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月23日，陈川平、聂春玉两人被查，当天下午，山西省委即召开会议，报道称，山西省委召开的常委会由省委书记袁纯清主持，省委副书记、省长李小鹏出席。在8月24日的报道中也是头版头条。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;今天的《山西日报》也将昨天的山西省委表态以头版头条报道。\n</p>\n<p style=\"font-size:14px;\">\n	<strong>&emsp;&emsp;表态·意义体现了决策的权威性</strong>\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;《人民论坛》杂志曾刊文将中国官场表态文化分为五个类型：一是“完全赞成、衷心拥护”型，二是“全面贯彻、坚决执行”型，三是“认真研究，迅速处理”型，四是“研究协调，妥善处理”型，五是“大声嚷嚷，高调宣扬”型。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;文章将这五种类型的表态文化概括为服从式、命令式、商量式、作秀式。“完全赞成、衷心拥护”型和“全面贯彻、坚决执行”型，属于服从式。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;“完全赞成、衷心拥护”所涉及的对象主要是上级的决策和精神，政治上保持一致的原则决定这种表态是必须的。“全面贯彻、坚决执行”所涉及的对象则既有上级的精神，也有上级领导个人的意志。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;这种表态一般会形成具体的落实措施，相当于做出“承诺”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;这种表态，既体现了决策的权威性，也体现了表态一方的决心与承诺，同时也是舆论引导的一个关键环节。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;此外官场表态还有维护稳定的作用，这点从在位高官被查上尤为明显。对于被调查者的同事或者继任者们来说，最重要的是保持稳定，同时工作还得开展。他们的出面表态对安定人心有着很大的作用。\n</p>',28,'D','2014-08-31 23:53:28',1,'2014-11-28 14:38:51',1);
INSERT INTO `tb_news` VALUES (2,'王岐山四个反腐新说法盘点：瞪眼发现问题','人们发现，自打就任中纪委书记以来，王岐山的“曝光率”明显减少了。如今的反腐势头如火如荼，“打老虎”、“拍苍蝇”成为常态，王岐山操盘，显得神秘了许多。不过，最近王岐山在政协常委会上应邀作报告，并和政协常委进行互动的事，又让他不得不又“火”了起来。','2014-08-31','<p style=\"text-align:center;\">\n	<img src=\"http://i2.sinaimg.cn/dy/c/2014-08-31/1409451620_tjj2dS.jpg\" alt=\"王岐山\" title=\"王岐山\" /> \n</p>\n<p style=\"text-align:center;\">\n	王岐山\n</p>\n<p style=\"font-size:14px;\">\n	<br />\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;人们发现，自打就任中纪委书记以来，王岐山的“曝光率”明显减少了。如今的反腐势头如火如荼，“打老虎”、“拍苍蝇”成为常态，王岐山操盘，显得神秘了许多。不过，最近王岐山在政协常委会上应邀作报告，并和政协常委进行互动的事，又让他不得不又“火”了起来。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;前些年，王岐山在国务院工作时，不时会有媒体爆些“私料”——比如一些现场脱稿讲话内容，常常被冠以幽默、睿智，读来让人十分过瘾。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;那么，王岐山对于反腐工作有什么新说法呢？待我们稍作盘点。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;<strong>“路上”说</strong> \n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;关于8月25日的政协常委会，官方媒体的报道里提到，王岐山表示“作风建设永远在路上”。不过，也有多家媒体采访了与会人员称，“在会议的最后，王岐山以‘反腐永远在路上’作为结语，再次赢得全场热烈掌声”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;强国论坛有位网民发表文章称，这两个“永远在路上”阐明了党和政府与腐败势不两立的坚定决心和态度，更对一段时间以来，不管是有人有意制造、传播，还是有人疑虑重重的“反腐终点论”、“反腐上限论”和“反腐拐点论”等，是一个有力辟谣；对那些反腐不作为和反腐以后工作不作为的相关部门和工作人员，是一个重锤猛敲。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;<strong>“标本”说</strong> \n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;同样是在8月25日的政协常委会上，王岐山说，在每天公布案件、打苍蝇老虎治标的同时，治本实际上已在推进。治本是一个系统工程，在推进制度性建设中，除了中央八项规定的执行之外，比如公务员薪酬、报账制度也都在抓紧修改。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;其实，翻看新闻报道，王岐山最常说的一段话就是“要加强理想信念教育，使领导干部‘不想腐’；强化制度建设和监督管理，使领导干部‘不能腐’；坚持有腐必惩、有贪必肃，使领导干部‘不敢腐’。”这“三不”清晰明确，就是科学理想的治本之策，也是杜绝腐败的有效武器。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;<strong>“瞪眼”说</strong> \n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;王岐山十分重视巡视工作，他分别在2013年5月和10月，2014年的3月和7月主持召开了四次有关巡视工作的会议。他说，巡视组要当好党中央的“千里眼”，找出“老虎”和“苍蝇”，对违纪违法问题早发现、早报告。又说，要瞪大眼睛发现问题，不能睁一只眼闭一只眼。还说，哪里问题集中就巡视哪里，谁问题突出就巡视谁，巡视过后再杀个回马枪。巡视是给党的肌体作“体检”，党内监督没有禁区、没有例外。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;过去一年间，中央巡视组共对20多个地方、部门和企事业单位进行了巡视，发现有价值的问题线索比过去增加了5倍。这双“瞪大”了的“千里眼”果然值得信赖！\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;<strong>“大小”说</strong> \n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;去年5月，王岐山在出席全国纪检监察系统开展会员卡专项清退活动电视电话会议时说，会员卡虽小，折射出的却是作风建设的大问题，反映的是享乐主义和奢靡之风。这次活动标准并不高，既属必要，又具可行，应是大家都能做到的。自此之后，对于月饼、台历、购物卡等各种“小事”的盯紧不放，让人愈发觉得背后“大有深意”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;王岐山说，纠正“四风”要从点滴做起，由浅入深、由易到难、循序渐进，一个阶段一个阶段地抓，坚持数年，必见成效。\n</p>',25,'D','2014-08-31 23:54:58',1,'2014-11-28 14:39:36',1);
INSERT INTO `tb_news` VALUES (3,'山西官场强震后省委书记《求是》撰文谈反腐','8月31日，《人民日报》第四版发布广告，公布了9月1日即将出版的《求是》杂志(2014年第17期)目录。目录显示，山西省委书记袁纯清将发表题为《切实落实主体责任 旗帜鲜明反对腐败》的文章。','2014-08-31','<p style=\"text-align:center;\">\n	<img src=\"http://i1.sinaimg.cn/dy/c/2014-08-31/U10608P1T1D30770937F21DT20140831083149.jpg\" alt=\"8月31日刊登在《人民日报》的，即将出版的9月1日《求是》杂志目录。\" title=\"8月31日刊登在《人民日报》的，即将出版的9月1日《求是》杂志目录。\" />\n</p>\n<p style=\"text-align:center;\">\n	8月31日刊登在《人民日报》的，即将出版的9月1日《求是》杂志目录。\n</p>\n<p style=\"text-align:center;\">\n	<img src=\"http://i3.sinaimg.cn/dy/c/2014-08-31/U10608P1T1D30770937F23DT20140831083149.jpg\" alt=\"山西官场现动荡，《人民日报》预报中共中央机关刊物《求是》将刊登山西省委书记署名反腐文章。 CFP \" title=\"山西官场现动荡，《人民日报》预报中共中央机关刊物《求是》将刊登山西省委书记署名反腐文章。 CFP \" />&emsp;&emsp;\n</p>\n<p style=\"text-align:center;\">\n	山西官场现动荡，《人民日报》预报中共中央机关刊物《求是》将刊登山西省委书记署名反腐文章。 CFP\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月31日，《人民日报》第四版发布广告，公布了9月1日即将出版的《求是》杂志(2014年第17期)目录。目录显示，山西省委书记袁纯清将发表题为《切实落实主体责任 旗帜鲜明反对腐败》的文章。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;就在2天前，8月29日，中央纪委监察部网站一日宣布山西两名高官山西省常委、统战部部长白云及<a href=\"http://news.sina.com.cn/c/2014-08-29/201530766290.shtml\" target=\"_blank\">山西省副省长任润厚被调查</a>，山西官场再度强震。一周前，山西刚刚同日宣布太原市委书记陈川平、省委秘书长聂春玉两名省常委被查。更早前几个月时任省委常委、副省长杜善学，时任省政协副主席令政策，时任省人大常委会副主任金道铭等也相继被查。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;金道铭被查前刚刚卸任山西省委副书记。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;另外，4月12日落马的时任中国科协党组书记、常务副主席申维辰也因山西事发。2010年9月调任中宣部副部长前，申维辰任太原市委书记，同样是山西省委常委。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;目前，山西官场半年内已有8位高官(包括申维辰)出事。13名常委的省委班子短短数月之内，则有4名省委常委在任时先后被拿下，可谓规模空前。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;白云、任润厚被宣布被调查后第二天，8月30日山西省委即第三次表态，坚决拥护中央决定，与中央保持高度一致。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月31日的《山西日报》也刊登了表态的文章，不过文章及版面并未提及省委书记袁纯清的讲话或者活动。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;这样没有提及袁纯清的报道，在山西官媒中关于山西省委活动的报道比较少见。8月30日晚间播出的山西卫视《新闻联播》率先披露了这一表态，不过，袁纯清同样没有出现在报道中。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;此前一周，他的工作依旧繁忙，仅“缺席”了8月26日的山西卫视《新闻联播》活动报道。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;据山西卫视报道，8月29日中央纪委网站公布了山西省委常委、统战部长白云、副省长任润厚涉嫌严重违纪违法接受组织调查，山西省委、省政府就此做出表态，坚决拥护中央决定，与中央保持高度一致。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;这已经是今年以来，山西省委第三次、山西省政府第二次就该省省部级官员落马事件进行表态。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;山西省政府党组会议依旧由省政府党组书记、省长李小鹏主持召开，但与此前两次表态不同的是，山西省此次并未以召开省委常委会的形式进行表态，而是代以笼统的“山西省委表态”、“山西省委认为”和“山西省委要求”。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;8月23日，陈川平、聂春玉两人被查，当天下午，山西省委即召开会议，表示坚决拥护中央决定。当时报道称，山西省委召开的常委会由省委书记袁纯清主持，省委副书记、省长李小鹏出席。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;6月19日，山西省省委常委、副省长杜善学，省政协副主席令政策被查，第二天上午即召开山西省委常委会(扩大)会议，表态坚决拥护中央决定，《山西日报》报道，该会由省委书记袁纯清主持。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;然而，在山西省官场动荡之际，袁纯清关于反腐的文章将刊登在《求是》杂志，引起新一轮关注。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;《求是》杂志是中共中央主办的机关刊物，一直是中共中央的重要思想理论阵地。该杂志作者队伍中，领导干部云集。以篇目论，省部级以上领导干部的文章要占到总量的40%以上，党和国家领导人的文章约占总量的5%。今年5月，《南方周末》还专门介绍过，“《求是》杂志如何刊发领导人的文章”。其中介绍，省部级及以下官员的稿件大多是主动投稿的，省部级官员发稿要“排队”。省部级官员的稿件可能要拖两三期才能发，有些副省部级官员的稿件则可能要等上半年。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;《求是》杂志是个半月刊，按照此一惯例，袁纯清即将在《求是》发表的《切实落实主体责任 旗帜鲜明反对腐败》一文，应该在上一期之前就已经“排队”。袁纯清撰写该文时，或许还没有想到短短一周内山西官场有4名省部级官员先后落马。\n</p>\n<p style=\"font-size:14px;\">\n	&emsp;&emsp;不过，就今年而言，袁纯清在《求是》杂志投稿密集。一个月前的7月16日，2014年第14期还曾发表了袁纯清《践行“三严三实” 永葆优良作风》的文章。其两个月内已在《求是》发表2篇文章。检索发现去年，袁纯清在《求是》共发表过3篇文章。&nbsp;\n</p>',28,'A','2014-08-31 23:56:24',1,'2014-08-31 23:56:24',1);
INSERT INTO `tb_news` VALUES (4,'第十六届骨科学术会议暨第九届COA国际学术大会','','2014-12-01','<p class=\"MsoTitle\">\n	<span style=\"font-family:创艺简仿宋;\">中华医学会第十六届全国骨科学术会议暨第九届<span>COA</span>国际学术大会<span></span></span> \n</p>\n<p class=\"MsoNormal\" align=\"left\" style=\"text-indent:21pt;\">\n	<br />\n</p>\n<p class=\"MsoNormal\" style=\"text-indent:21.0pt;\">\n	<img width=\"24\" height=\"22\" src=\"file://C:/Users/user/AppData/Local/Temp/msohtmlclip1/01/clip_image004.png\" align=\"left\" /><span style=\"font-size:12.0pt;font-family:创艺简仿宋;\">本次的<span>COA</span>我们将重点摆在预防感染，隆重的推出贺利氏即将登场的翻修、双抗生素等新骨水泥系列产品呢，以及雷德睦华代理进口的脊柱骨水泥搅拌注射器，届时有关新产品的动态及消息，请继续关注我们官方网站或是微信号《骨水泥专家》。</span><span style=\"font-size:12.0pt;font-family:宋体;\"></span> \n</p>\n<p class=\"MsoNormal\" style=\"text-indent:21.0pt;\">\n	<span style=\"font-size:12.0pt;font-family:创艺简仿宋;\">最后以大会主席田伟教授所引用的鲁迅的“自己背着因袭的重担，肩住了黑暗的闸门，放他们到宽阔光明的地方去；此后幸福的度日，合理的做人。”我们致力于提供您信赖的绿色骨水泥！<span style=\"color:red;\"></span></span> \n</p>\n<p class=\"MsoNormal\" align=\"left\">\n	<img width=\"521\" height=\"346\" src=\"file://C:/Users/user/AppData/Local/Temp/msohtmlclip1/01/clip_image006.jpg\" align=\"left\" /><span style=\"font-size:12.0pt;font-family:创艺简仿宋;\"></span> \n</p>',1,'I','2014-11-28 14:42:39',1,'2014-12-01 16:37:56',1);
/*!40000 ALTER TABLE `tb_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_partner`
--

DROP TABLE IF EXISTS `tb_partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_partner` (
  `id` int(11) NOT NULL,
  `type` char(1) NOT NULL,
  `name` varchar(200) NOT NULL,
  `logo_file` varchar(200) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `contacter` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city_id` int(11) NOT NULL,
  `coordinate` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `weixin` varchar(255) NOT NULL,
  `summary` varchar(1000) NOT NULL,
  `content` text NOT NULL,
  `remark` varchar(255) NOT NULL,
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_partner`
--

LOCK TABLES `tb_partner` WRITE;
/*!40000 ALTER TABLE `tb_partner` DISABLE KEYS */;
INSERT INTO `tb_partner` VALUES (0,'H','1','14081617037ico.png','2','4','3','5','6',1,'7','8','9','10','11','12','D',1,'2014-08-16 17:09:31',1,'2014-08-16 19:17:42');
INSERT INTO `tb_partner` VALUES (1,'H','雷德睦华医院（上海）','','137111014','','','aaa','上海市人民大道200号',355,'121.480285,31.236221','http://','','','非常不错','','D',1,'2014-08-16 19:22:54',1,'2014-08-16 19:23:59');
INSERT INTO `tb_partner` VALUES (2,'S','雷德睦华总代理（北京）','14081716012logo1.png','010-58032661 ','010-58032661 ','010-58032661 ','陈先生','北京市丰台区马家堡东路106号自然新天地写字楼606室',1,'116.393463,39.847131','http://','','','暂无详情','','A',1,'2014-08-17 16:10:02',1,'2014-08-17 16:10:02');
INSERT INTO `tb_partner` VALUES (3,'H','雷德睦华医院（上海）','14081716011logo1.png','020-5002200','020-5002200','020-5002200','林先生','上海市人民大道200号',355,'121.480262,31.236238','http://','','','暂无详情','','A',1,'2014-08-17 16:10:54',1,'2014-08-17 16:13:56');
INSERT INTO `tb_partner` VALUES (4,'D','雷德睦华医生（深圳）','','0755-25578945','0755-25578945','0755-25578945','蔡先生','深圳市罗湖区文锦中路1008号罗湖管理中心大厦',214,'114.138108,22.554558','','','','暂无详情','','A',1,'2014-08-17 16:12:13',1,'2014-08-17 16:12:13');
INSERT INTO `tb_partner` VALUES (5,'S','雷德睦华代理（长沙）','14081716025logo1.png','0731-889999176','0731-889999176','0731-889999176','王小姐','长沙市芙蓉区人民东路189号',199,'113.002354,28.191841','','','','暂无详情','','A',1,'2014-08-17 16:13:13',1,'2014-08-17 16:13:13');
/*!40000 ALTER TABLE `tb_partner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_partner_type`
--

DROP TABLE IF EXISTS `tb_partner_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_partner_type` (
  `code` char(1) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_partner_type`
--

LOCK TABLES `tb_partner_type` WRITE;
/*!40000 ALTER TABLE `tb_partner_type` DISABLE KEYS */;
INSERT INTO `tb_partner_type` VALUES ('D','医生','A');
INSERT INTO `tb_partner_type` VALUES ('H','医疗机构','A');
INSERT INTO `tb_partner_type` VALUES ('S','供应商','A');
/*!40000 ALTER TABLE `tb_partner_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_product`
--

DROP TABLE IF EXISTS `tb_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_product` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `seq` varchar(10) NOT NULL,
  `summary` varchar(250) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `content` text,
  `status` char(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_product`
--

LOCK TABLES `tb_product` WRITE;
/*!40000 ALTER TABLE `tb_product` DISABLE KEYS */;
INSERT INTO `tb_product` VALUES (1,2,'聚乳酸手术保护膜','1','SurgiWrap聚乳酸手术保护膜（简称“MAST膜”）是由美国MAST Biosurgery Inc.研制生产。','14102919043SurgiWrap.png','\n<section class=\"page-contain\">\n    <div class=\"container\">\n        <div class=\"row\">\n            <h4>\n                产品介绍\n            </h4>\n            <div class=\"span8\">\n                <div>\n                    <p>\n                        SurgiWrap聚乳酸手术保护膜（简称“MAST膜”）是由美国MAST Biosurgery Inc.研制生产。\n                    </p>\n                    <p>\n                        组织粘连的产生是人体自然愈合过程中的一部分，也是外科手术后软组织修复的一个严重并发症。这种不良的无法控制的现象会导致手术失败和愈后不良，例如肠梗阻、盆腹腔痛、不孕症、心包粘连、肌腱灵活性降低、瘢痕组织引起的神经束膜疼痛、压迫神经疼痛以及脑膜搏动引起植入物碎裂等症状发生。\n                    </p>\n                    <p>\n                        另外，在需要二次手术时，松解初次手术后形成的瘢痕组织，使得二次手术更加复杂。松解瘢痕组织的过程，会增加病人手术的风险， 如划伤血管及神经，并延长手术时间及加大手术难度，这类手术包括心脏手术、肝脏手术、甲状腺手术等。\n                    </p>\n                    <p>\n                        MAST膜用于有效防止术后组织粘连，增强和支撑软组织，恢复原有解剖面的清晰度。MAST膜也可作为临时创伤支持体，或疝修补的桥接材料。\n                    </p>\n                </div>\n            </div>\n            <div class=\"span4\" style=\"text-align:center;\">\n                <img src=\"/themes/lm/images/mask.png\" />\n            </div>\n        </div>\n        <hr />\n        <div class=\"row\">\n            <h4>\n                特殊的材料工艺\n            </h4>\n            <div class=\"span12\">\n                <table>\n                    <tbody>\n                        <tr>\n                            <td width=\"30px\"></td>\n                            <td></td>\n                        </tr>\n                        <tr>\n                            <td>\n                                1.\n                            </td>\n                            <td>\n                                MAST可吸收生物膜是由特殊的聚乳酸组成：其聚合比例为70：30（L-lactide-co-DL-lactide），与软组织、硬脑膜、骨组织、骨髓、脊髓、神经组织相容，这被国际上的很多医疗与研究机构证明是最符合人体的生物医学材料。\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                2.\n                            </td>\n                            <td>\n                                采用特殊制造工艺的MAST膜是非晶状结构的高分子膜，结合了左旋聚乳酸（PLLA，l-lactide）高的强度和消旋聚乳酸（PDLLA,DL-lactide）良好的吸收度，它可以在愈合过程中保持一定的强度，在体内均匀的分层降解而不是碎裂或其它方式降解，降低炎症反应风险，具有安全的吸收和代谢性。\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                3.\n                            </td>\n                            <td>\n                                MAST膜的乳酸与人体自然产生的乳酸相同，可以水解为乳酸单体，最后由肝脏代谢二氧化碳和水安全释放到体外。\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                4.\n                            </td>\n                            <td>\n                                一般的聚乳酸产品几乎都是消旋DL聚乳酸（PDLLA,DL-lactide）的胶或者是膜，呈现高粘性且消融极快的结构，不仅在体内停留的时间极短，更会在伤口聚集高浓度的乳酸堆积。\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                5.\n                            </td>\n                            <td>\n                                无人类或动物成分，避免严重免疫原性风险和传染疾病的传播。\n                            </td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n        </div>\n        <br />\n        <hr />\n        <div class=\"row\">\n            <h4>\n                特性与优点\n            </h4>\n            <div class=\"span7\">\n                <p>\n                    有效隔离长达6周，足以在愈合的关键时期起防止粘连以及支撑保护的作用。<br />\n                    透明且形态超薄，使用时不影响手术视野，并可以重新放置。\n                </p>\n                <table border=\"1px\">\n                    <tbody>\n                        <tr>\n                            <td width=\"200px\" style=\"border:1px;\">\n                                特性\n                            </td>\n                            <td style=\"border:1px;\">\n                                优点\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                聚乳酸\n                            </td>\n                            <td>\n                                安全吸收代谢，缓慢释放不会在伤口聚集高浓度的乳酸\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                不渗透\n                            </td>\n                            <td>\n                                在软组织之间建立临时物理性屏障 <br />\n                                在关键的伤口愈合期确保分隔软组织，有效隔离达6周\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                潮湿状态可重复放置\n                            </td>\n                            <td>\n                                在解剖部位轻松放置定位 <br />\n                                不会黏附外科手术手套或器械\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                可以剪裁、折叠\n                            </td>\n                            <td>\n                                适合不同的解剖位置，方便手术需要\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                透明\n                            </td>\n                            <td>\n                                不遮挡手术视野，方便手术操作和重新放置\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                可使用缝线、可吸收夹、外科针固定\n                            </td>\n                            <td>\n                                确保产品不离开需要保护的位置\n                            </td>\n                        </tr>\n                    </tbody>\n                </table>\n                <br />\n            </div>\n            <div class=\"span5\" style=\"text-align:center;\">\n                <p>\n                    <br />\n                </p>\n                <img src=\"/themes/lm/images/data.png\" /><br />\n                <p>\n                    韧度保持与吸收\n                </p>\n            </div>\n            <div class=\"span12\">\n                <p>\n                    三方实验室研究证明，MAST膜能够在关键的愈合期维持性状不改变，在愈合期保证软组织愈合，直至6~8周软组织增强。Elkins et al. and Bellina et al.都指出，术中采用电刀后，烧灼部位软组织的愈合，因高温碳化造成炎性反应，至少需要3周的时间。MAST膜可以保持足够的韧度和完整性，在相邻组织之间形成一个临时物理屏障，以避免粘连形成，也可做为临时创伤支持与桥接材料。\n                </p>\n            </div>\n            <div class=\"span12\" style=\"text-align:center;\">\n                <p>\n                    <img src=\"/themes/lm/images/mast/pic1.png\" /> <img src=\"/themes/lm/images/mast/pic2.png\" /> <img src=\"/themes/lm/images/mast/pic3.png\" />\n                </p>\n            </div>\n            <div class=\"span12\">\n                <p>\n                    MAST膜可用于隔离软组织，形成解剖面，促进愈合，防止粘连形成。提供临时支撑，以增强软组织，可作为其他筋膜修补加固或桥接材料，包括但不限于下列手术：疝修复、阴道脱垂修补，结肠、直肠脱垂修补，骨盆底重建，肌腱修补手术中加强修补软组织。\n                </p>\n            </div>\n        </div>\n        <hr />\n        <div class=\"row\">\n            <h4>\n                应用特性\n            </h4>\n            <div class=\"span12\">\n                <p>\n                    <br />\n                </p>\n                <ul style=\"margin-left:0px;\">\n                    <li>\n                        美国FDA认证可同时用于开放和腔镜手术的生物可吸收薄膜。\n                    </li>\n                    <li>\n                        国际认证可用于全外科系、骨科及妇产科等任何外科手术后，需要临时保护和增强的隔离保护膜。\n                    </li>\n                    <li>\n                        是同时具有支撑隔离保护，以及防止粘连的物理性膜，可以在创面的两侧形成假性的隔离保护膜。\n                    </li>\n                </ul>\n                <p>\n                    <br />\n                </p>\n            </div>\n        </div>\n        <hr />\n        <div class=\"row\">\n            <h4>\n                规格尺寸\n            </h4>\n            <div class=\"span8\">\n                <table border=\"1px\">\n                    <tbody>\n                        <tr style=\"background-color:#4682B4;color:white;\">\n                            <td width=\"200px\" style=\"border:1px;\">\n                                产品型号\n                            </td>\n                            <td style=\"border:1px;\" width=\"400px\">\n                                产品规格\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25201-01\n                            </td>\n                            <td>\n                                50mm×70mm×0.02mm\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25202-01\n                            </td>\n                            <td>\n                                100nlm×130mm×0.02mm\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25204-01\n                            </td>\n                            <td>\n                                130mm×200mm×0.02mm\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25501-01\n                            </td>\n                            <td>\n                                50mm×70mm×0.05mm\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25502-01\n                            </td>\n                            <td>\n                                100mm×130mm×0.05mm\n                            </td>\n                        </tr>\n                        <tr>\n                            <td>\n                                25504-01\n                            </td>\n                            <td>\n                                130mm×200mm×0.05mm\n                            </td>\n                        </tr>\n                    </tbody>\n                </table>\n                <br />\n            </div>\n            <div class=\"span4\">\n                <img src=\"/themes/lm/images/mast/sample.png\" />\n            </div>\n        </div>\n        <br />\n        <hr />\n        <div class=\"row\">\n            <h4>\n                建议适用手术\n            </h4>\n            <div class=\"span12\">\n                <ul style=\"margin-left:0px;\">\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        脑硬膜的隔离保护：提供二次手术较短的进入时间，与较佳的解剖可视性，并降低癫痫的程度。强烈建议不能取代硬脑膜或硬脑膜修补片，须置于硬脑膜或硬脑膜修补片外，或缝合与颅骨的骨膜上，以避免阻隔脊髓液的流动。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        甲状腺摘除之隔离保护：避免二次手术因解剖不清而伤及甲状旁腺与喉返神经。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        心包与心血管的保护隔离：提供二次手术时清晰的解剖可视性，缩短手术时间，避免因解剖不清而划伤心血管。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        腹壁的隔离保护：腹腔与骨盆腔手术腹壁正中切口下粘黏的预防。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        腹腔内脏器手术伤口的保护隔离：包括肝胆胃的切除与移植手术。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        骨盆腔脏器手术伤口的保护隔离：包括肛肠的切除与淋巴括除手术，泌尿系统手术，以及妇女生殖器手术。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        手足外科手术肌腱神经的保护隔离：筋膜吻合肌腱接合手术软组织的隔离保护，关节粘黏松解的处理。\n                    </li>\n                    <li style=\"list-style:disc;margin-bottom:10px;\">\n                        脊柱硬脊膜粘黏的保护隔离：包括椎间盘减压手术，椎体融合手术硬脊膜粘黏的保护隔离。\n                    </li>\n                </ul>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <h6>\n                    腔镜手术（大外科与妇产科）\n                </h6>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s1.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s2.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s3.png\" />\n                    </p>\n                </div>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <h6>\n                    心脏血管手术\n                </h6>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s4.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s5.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s6.png\" />\n                    </p>\n                </div>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <h6>\n                    神经与肌腱手术\n                </h6>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s7.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s8.png\" />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s9.png\" />\n                    </p>\n                </div>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        脊柱手术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s10.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        颅骨手术（配合修补片）\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s11.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        膝关节粘连松解术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/upload/download/14110316026膝关节粘连松解术.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        甲状腺手术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s13.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        临时造瘘术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s14.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        腹膜闭合手术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s15.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n            </div>\n            <div class=\"row\" style=\"text-align:center;\">\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        疝气修补片搭桥\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s16.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        肝移植及肝胆切除术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s17.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n                <div class=\"span4\">\n                    <p>\n                        <br />\n                    </p>\n                    <h6>\n                        妇产科手术\n                    </h6>\n                    <img style=\"width:288px;\" src=\"/themes/lm/images/mast/s18.png\" />\n                    <p>\n                        <br />\n                    </p>\n                </div>\n            </div>\n        </div>\n        <p>\n            以及其他吻合手术（血管、神经、输卵管、输精管、输尿管）的保护隔离与防粘连。\n        </p>\n    </div>\n    </div>\n</section>','A','2014-10-29 19:46:29',1,'2014-11-06 13:15:31',1);
INSERT INTO `tb_product` VALUES (2,1,'PALAMIX&reg;真空混合系统','3','完美组合，通过连贯的系统实现协同','14110417041p7_副本.png','<section class=\"page-contain\">\n    <div class=\"container\">\n<div class=\"row\">\n	<h4>\n		产品介绍\n	</h4>\n	<div class=\"span12\">\n		<div>\n			<p>\n				PALAMIX&reg;真空混合系统是PALACOS骨水泥具备卓越操作性能的秘诀，可提供均匀的水泥混合物。标准化混合过程可生产均匀的混合物，而产生设计可实现水泥的最佳使用。PALAMIX&reg;易于使用，有助于外科手术的顺利完成。\n			</p>\n			<p>\n				在现代化骨水泥技术中，不同元素的组合对长期的手术结合至关重要。如今，“先进水平”不仅指选择具备合适的粘度和成分的骨水泥，还包括可生产均匀、标准化混合物的真空混合系统，使用脉冲冲洗系统清洁骨床及加压器的应用。\n			</p>\n		</div>\n	</div>\n</div>\n<hr />\n<div class=\"row\">\n	<h4>\n		特性和优点\n	</h4>\n	<div class=\"span6\">\n		<ul>\n			<li>\n				<h5>\n					脉冲冲洗系统\n				</h5>\n				<p>\n					除真空混合及加压外，使用脉冲冲洗系统清洁骨床也是现代化骨水泥胶合技术中的一个重要方面。研究数据（4）显示，翻修率大大降低。通过脉冲冲洗系统可有效清洁骨床，为手术部位做好最佳准备，以便于灌注水泥。\n				</p>\n			</li>\n			<li>\n				<h5>\n					产品范围广泛\n				</h5>\n				<p>\n					无论是全骨水泥式混合式植入物，大关节或小关节，PALAMIX&reg;针对每一适应症提供不同尺寸的套筒准备，以便于灌注水泥。\n				</p>\n			</li>\n			<li>\n				<h5>\n					骨水泥残留量低\n				</h5>\n				<p>\n					使用PALAMIX&reg; 80的套筒混合2包40g的PALACOS骨水泥，最终92.5%的骨水泥都能够使用。\n				</p>\n			</li>\n		</ul>\n	</div>\n	<div class=\"span6\">\n		<img width=\"508px\" src=\"/kindeditor/php/../attached/image/20141104/20141104165720_74512.png\" alt=\"\" /> \n	</div>\n</div>\n<hr />\n<div class=\"row\">\n	<h4>\n		规格尺寸\n	</h4>\n	<div class=\"span12\">\n		<table>\n			<tbody>\n				<tr>\n					<td width=\"20px\">\n					</td>\n					<td width=\"300px\">\n						产品\n					</td>\n					<td style=\"border:1px;\" width=\"400px\">\n						描述\n					</td>\n					<td style=\"border:1px;\" width=\"400px\">\n						内容物\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX uno 1 x 40\n					</td>\n					<td rowspan=\"3\">\n						真空混合系统\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX uno 1 x 80\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX uno 1 x 120\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX duo 2 x 40\n					</td>\n					<td rowspan=\"2\">\n						两件装真空混合系统\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX duo 2 x 80\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX duo hip 1 x 40/1 x 80\n					</td>\n					<td>\n						两件装髋关节真空混合系统\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td rowspan=\"4\">\n						附件\n					</td>\n					<td>\n						PALAMIX水泥喷枪\n					</td>\n					<td>\n						1\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX真空泵\n					</td>\n					<td>\n						1\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX中等喷嘴\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n				<tr>\n					<td>\n					</td>\n					<td>\n						PALAMIX细长喷嘴\n					</td>\n					<td>\n						10\n					</td>\n				</tr>\n			</tbody>\n		</table>\n<br />\n	</div>\n	<div class=\"row\">\n		<div class=\"span3\">\n			<img src=\"/kindeditor/php/../attached/image/20141104/20141104165721_99347.png\" alt=\"\" /> \n		</div>\n		<div class=\"span3\">\n			<img src=\"/kindeditor/php/../attached/image/20141104/20141104165721_55639.png\" alt=\"\" /> \n		</div>\n		<div class=\"span3\">\n			<img src=\"/kindeditor/php/../attached/image/20141104/20141104165722_51921.png\" alt=\"\" /> \n		</div>\n		<div class=\"span3\">\n			<img src=\"/kindeditor/php/../attached/image/20141104/20141104165722_38419.png\" alt=\"\" /> \n		</div>\n	</div>\n</div>\n<br />\n<hr />\n<div class=\"row\">\n	<h4>\n		实物图\n	</h4>\n	<div class=\"span12\">\n		<img src=\"/kindeditor/php/../attached/image/20141104/20141104165724_52478.png\" alt=\"\" /> \n	</div>\n</div>\n    </div>\n</section>','A','2014-11-04 17:04:02',1,'2014-11-06 14:22:19',1);
INSERT INTO `tb_product` VALUES (3,1,'PALACOS&reg;骨水泥','1','卓越的现代化骨水泥技术','14110713050Palacos-内容logo.png','<!-- Start parallax -->\n    <section class=\"parallax parallax-bgpala\">\n<div class=\"page-spacer\">\n	<div class=\"container\">\n		<div class=\"row margintop50\">\n			<div class=\"span12 aligncenter\">\n				<h3>\n					品质、专业、创新。\n				</h3>\n				<h5>\n					适用于关节置换术的现代化骨水泥技术。\n				</h5>\n			</div>\n		</div>\n	</div>\n</div>\n</section>\n    <!-- End parallax -->\n    <section class=\"page-contain\">\n<div class=\"container\">\n	<div class=\"row\">\n		<h4>\n			PALACOS&reg;R+G<br />\nPALACOS&reg;R\n		</h4>\n		<h4 style=\"color:#7FC600;\">\n			原装品质 德国制造\n		</h4>\n		<div class=\"span7\">\n			<div>\n				<p>\n					50 多年来，PALACOS&reg; 骨水泥一直是植入物长期锚定的黄金标准。完美融合现代\n                            专业知识与当 前 市场需求 – 是贺利氏成功的秘诀。贺利氏持续的开发与创新，使\n                            我们拥有更丰富的产品线。\n				</p>\n				<p>\n					除了选择合适的骨水泥外，现代化骨\n                            水泥技术的应用也对人工关节置换手术的成功与否起着至关重要的作用。\n				</p>\n				<p>\n					为此，贺利氏推出全面的产品组合，从高品质 PALACOS&reg; 骨水泥到创新 PALAMIX&reg; 真空混\n                            合系统再到用于清洗骨床的脉冲冲洗系统。\n				</p>\n				<p>\n					PALACOS&reg;是一款高粘度骨水泥。50多年来，PALACOS&reg;骨水泥秉持一贯的高品质原料和成熟的配方，为外科手术的成功做出了积极贡献。\n				</p>\n				<p>\n					PALACOS&reg;绿色的骨水泥，与周围组织形成清晰视觉对比，方便在手术过程中操作\n				</p>\n			</div>\n		</div>\n		<div class=\"span1\">\n		</div>\n		<div class=\"span4\" style=\"text-align:center;\">\n			<p>\n				<img src=\"http://www.gushuini.com/themes/lm/images/m3.png\" />\n			</p>\n			<div style=\"text-align:left;padding:20px;\">\n				<h6 style=\"color:#7FC600;\">\n					优势概览\n				</h6>\n				<ul>\n					<li style=\"list-style:disc;\">\n						关节置换术领域的黄金标准\n					</li>\n					<li style=\"list-style:disc;\">\n						可靠的配方，可依赖的性能\n					</li>\n					<li style=\"list-style:disc;\">\n						添加庆大霉素，低返修率\n					</li>\n					<li style=\"list-style:disc;\">\n						适合真空搅拌\n					</li>\n				</ul>\n			</div>\n		</div>\n	</div>\n	<hr />\n	<div class=\"row\">\n		<h4>\n			特性和优点\n		</h4>\n		<div class=\"span6\">\n			<h5>\n				翻修率低\n			</h5>\n			<p>\n				临床资料表明，使用PALACOS&reg;骨水泥锚定的植入物拥有更长的存活率。\n			</p>\n			<p>\n				使用PALACOS&reg;骨水泥锚定的植入物10年后需要翻修的几率远远低于使用其他骨水泥的植入物。\n			</p>\n			<div id=\"fanxiucontainer\" style=\"min-width:500px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n		<div class=\"span6\">\n			<h5>\n				抗生素预防优势\n			</h5>\n			<p>\n				所有PALAMIX&reg;骨水泥均可添加庆大霉素。抗生素的局部释放可将植入物的感染风险降至最低，\n                        并减少全身药物符合。\n			</p>\n			<p>\n				现在，PALAMIX&reg;R+G以极低的骨水泥人工关节翻修率而享有盛誉。\n			</p>\n			<div id=\"qingdacontainer\" style=\"min-width:500px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n	</div>\n</div>\n</section>\n    <!-- Start parallax -->\n    <section class=\"parallax parallax-bgpala\">\n<div class=\"page-spacer\">\n	<div class=\"container\">\n		<div class=\"row margintop50\">\n			<div class=\"span12 aligncenter\">\n				<h3>\n					多种选择，灵活应用\n				</h3>\n				<h5>\n					贺利氏所提供的 PALACOS&reg; 产品组合涵盖多种\n                            高品质骨水泥，用于锚定人工关节植入物。可选择\n                            不同的粘度，普通或添加抗生素的，灵活应用。\n				</h5>\n			</div>\n		</div>\n	</div>\n</div>\n</section>\n    <!-- End parallax -->\n    <!-- End parallax -->\n    <section class=\"page-contain\">\n<div class=\"container\">\n	<div class=\"row\">\n		<div class=\"span6\">\n			<h4>\n				PALACOS&reg; MV+G<br />\nPALACOS&reg; MV\n			</h4>\n			<p>\n				PALACOS&reg; MV 是一款中等粘度骨水泥。\n			</p>\n			<p>\n				其原料与 PALACOS&reg; R 相同，具备卓越的机械特性。PALACOS&reg; MV\n                        尤其适合与真空混合系统搭配使用。该骨水泥也提供含庆大\n                        霉素的版本，即 PALACOS&reg; MV+G，用于感染预防。\n			</p>\n			<ul>\n				<li style=\"list-style:disc;\">\n					适用于中大型关节\n				</li>\n				<li style=\"list-style:disc;\">\n					真空搅拌的最佳搭档\n				</li>\n				<li style=\"list-style:disc;\">\n					添加庆大霉素，实现抗生素预防\n				</li>\n				<li style=\"list-style:disc;\">\n					原料与 PALACOS&reg; R 相同，坚持一贯的高品质\n				</li>\n			</ul>\n		</div>\n		<div class=\"span2\">\n		</div>\n		<div class=\"span4\" style=\"text-align:center;\">\n			<img src=\"http://www.gushuini.com/themes/lm/images/m4.png\" /> \n		</div>\n	</div>\n	<div class=\"row\">\n		<div class=\"span4\" style=\"text-align:center;\">\n			<img src=\"http://www.gushuini.com/themes/lm/images/m5.png\" /> \n		</div>\n		<div class=\"span2\">\n		</div>\n		<div class=\"span6\">\n			<h4>\n				PALACOS&reg; LV+G<br />\nPALACOS&reg; LV\n			</h4>\n			<p>\n				PALACOS&reg; LV 是一款低粘度骨水泥。\n			</p>\n			<p>\n				由于粘度较低，PALACOS&reg; LV 即使通过细小的喷嘴亦可精\n                        确灌注，是肩肘等中小型关节的理想之选。PALACOS&reg; LV\n                        能够更好地渗透到细小的骨结构中，并提供良好的锚定性\n                        能。该骨水泥也提供添加庆大霉素的版本，即\n                        PALACOS&reg; LV+G，以实现抗生素预防。\n			</p>\n			<ul>\n				<li style=\"list-style:disc;\">\n					适用于中小型关节\n				</li>\n				<li style=\"list-style:disc;\">\n					低粘度，精确灌注\n				</li>\n				<li style=\"list-style:disc;\">\n					添加庆大霉素，用于感染预防\n				</li>\n				<li style=\"list-style:disc;\">\n					原料与 PALACOS&reg; R 相同，坚持一贯的高品质\n				</li>\n			</ul>\n		</div>\n	</div>\n	<hr />\n	<div class=\"row\">\n		<h4>\n			规格型号\n		</h4>\n		<div class=\"span12\">\n			<table>\n				<tbody>\n					<tr style=\"background-color:#4682B4;color:white;\">\n						<td width=\"200px\" style=\"border:1px;\">\n							产品\n						</td>\n						<td style=\"border:1px;\" width=\"400px\">\n							描述\n						</td>\n						<td style=\"border:1px;\" width=\"400px\">\n							内容物\n						</td>\n						<td style=\"border:1px;\" width=\"400px\">\n							参考号\n						</td>\n					</tr>\n					<tr valign=\"top\">\n						<td>\n							PALACOS&reg;R+G\n						</td>\n						<td>\n							含庆大霉素的高粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055102\n						</td>\n					</tr>\n					<tr valign=\"top\">\n						<td>\n							PALACOS&reg;R\n						</td>\n						<td>\n							高粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055101\n						</td>\n					</tr>\n					<tr valign=\"top\" style=\"background-color:#cccccc;\">\n						<td>\n							PALACOS&reg;MV+G\n						</td>\n						<td>\n							含庆大霉素的中粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055103\n						</td>\n					</tr>\n					<tr valign=\"top\" style=\"background-color:#cccccc;\">\n						<td>\n							PALACOS&reg;MV\n						</td>\n						<td>\n							中粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055192\n						</td>\n					</tr>\n					<tr valign=\"top\">\n						<td>\n							PALACOS&reg;LV+G\n						</td>\n						<td>\n							含庆大霉素的低粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055193\n						</td>\n					</tr>\n					<tr valign=\"top\">\n						<td>\n							PALACOS&reg;LV\n						</td>\n						<td>\n							低粘度骨水泥\n						</td>\n						<td>\n							1 X 40\n						</td>\n						<td>\n							66055194\n						</td>\n					</tr>\n				</tbody>\n			</table>\n<br />\n		</div>\n	</div>\n</div>\n</section>\n    <!-- Start parallax -->\n    <section class=\"parallax parallax-bgpala\">\n<div class=\"page-spacer\">\n	<div class=\"container\">\n		<div class=\"row margintop50\">\n			<div class=\"span12 aligncenter\">\n				<h3>\n					适合真空混合\n				</h3>\n				<h3>\n					灵活触动即可完成艰巨任务\n				</h3>\n			</div>\n		</div>\n	</div>\n</div>\n</section>\n    <!-- End parallax -->\n    <!-- End parallax -->\n    <section class=\"page-contain\">\n<div class=\"container\">\n	<div class=\"row\">\n		<h4>\n			其它特性\n		</h4>\n		<div class=\"span3\">\n			<p>\n				贺利氏所提供的PALACOS&reg;产品组合涵盖各种各样的高品质骨水泥，\n                        用于锚定人工关节植入物。可选择不同的粘度，添加或未添加抗生素，\n                        确保最大的灵活性，以实现各种应用。\n			</p>\n		</div>\n		<div class=\"span9\">\n			<div id=\"nianducontainer\" style=\"min-width:500px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n		<div class=\"span4\">\n			<div id=\"naiyacontainer\" style=\"min-width:300px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n		<div class=\"span4\">\n			<div id=\"tanxingcontainer\" style=\"min-width:300px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n		<div class=\"span4\">\n			<div id=\"wanqucontainer\" style=\"min-width:300px;height:400px;margin:0 auto;\">\n			</div>\n		</div>\n	</div>\n</div>\n</section>','A','2014-11-06 13:26:16',1,'2014-11-24 11:02:01',1);
INSERT INTO `tb_product` VALUES (4,1,'OSTEOPAL&reg;脊椎骨水泥','2','适用于脊柱外科手术的产品线。','14111000023osteopal_lbl.png','\n		<section class=\"page-contain\">\n			<div class=\"container\">\n				<div class=\"row\">\n					<h4 style=\"color:#CC9500\">脊柱外科领域的黄金标准</h4>\n					<div class=\"span8\">\n						<div>\n						<p>50 多年来，贺利氏一直是“德国制造”骨水泥的领\n先专家。得益于数十年的经验及 PALACOS&reg;. 的成\n功，贺利氏产品组合不断得到扩展。OSTEOPAL&reg; 产\n品组合扩展带来了三类脊柱水泥，可满足严苛的椎\n体加固要求。由此，贺利氏实现了广泛的应用，提\n供了巨大的灵活性。</p>\n						<p>脊椎骨水泥加固中的经典材料 OSTEOPAL&reg; V 是一款不透射\n线低粘度骨水泥，用于充填和稳固椎体。其通过混合聚合\n物粉末及液体单体成分制备。骨水泥粉末中添加了二氧化\n锆作为 X 射线造影剂，以达到最佳成像效果。\n凭借卓越的性能，在过去 10 年中充分证明\n了其在脊柱手术中的价值。\n该产品的配方基于 PALACOS&reg; 中所使用的原料，而\nPALACOS? 产品业已在无数的临床研究和注册中成功通过骨水泥测试。</p>\n						<br />\n						<div>\n							<h5>优势概览</h5>\n							<ul>\n								<li style=\"list-style:disc;margin-bottom:5px;\" >被视为脊柱外科手术中的黄金标准</li>\n								<li style=\"list-style:disc;margin-bottom:5px;\">粘度经过优化，便于应用</li>\n								<li style=\"list-style:disc;margin-bottom:5px;\">采用二氧化锆作为 X 射线造影剂，便于控制应用过程</li>\n							</ul>\n						</div>\n					</div>\n					</div>	\n					<div class=\"span4\" style=\"text-align:center;\">\n						<img src=\"/themes/lm/images/osteopal.png\" />\n					</div>\n				</div>\n			</div>\n		</section>\n		<!-- Start parallax -->\n		<section class=\"parallax parallax-bgost\">\n		    <div class=\"page-spacer\">\n		        <div class=\"container\">\n		            <div class=\"row margintop50\">\n		                <div class=\"span12 aligncenter\">\n		                    <h3 style=\"color:#CC9500\">在成像技术中提供标准、完美可视性</h3>\n		                    <h3 style=\"color:#CC9500\">显著提高了动态负载疲劳强度</h3>\n		                </div>\n		            </div>\n		        </div>\n		    </div>\n		</section>\n		<!-- End parallax -->\n		\n		<section class=\"page-contain\">\n			<div class=\"container\">\n				<div class=\"row\">\n		            <h4>其它特性</h4>\n		            <div class=\"span5\">\n		               <ul>\n		               		<li>\n								<h6 style=\"color:#CC9500\">安全来自于 PALACOS&reg;的材料</h6>\n								<div>\n									<p>低粘度的骨水泥OSTEOPAL&reg; V系专门为此项外科技术而开\n									发。因此OSTEOPAL&reg; V在这种治疗方法中呈现出很重要的\n									产品优点</p>\n								</div>\n							</li>\n		               		<li>\n								<h6 style=\"color:#CC9500\">低粘度便于注射</h6>\n								<div>\n									<p>OSTEOPAL&reg; V初始阶段粘度低，固化阶段短暂–这样极利于骨水泥通过针管。</p>\n								</div>\n		               		</li>\n		               		<li>\n								<h6 style=\"color:#CC9500\">整个注射过程全方位控制</h6>\n								<div>\n									<p>OSTEOPAL&reg; V 含有高剂量显影剂 ZrO2、成像极为清晰。</p>\n								</div>\n		               		</li>\n		               		<li>\n								<h6 style=\"color:#CC9500\">出众的机械特性</h6>\n								<div>\n									<p>OSTEOPAL&reg; V 的物理性能极佳。 抗弯强度、抗压强度以及弹性模量都远远超出国际标准ISO 5833。</p>\n								</div>\n		               		</li>\n		               </ul>\n		            </div>\n		            <div class=\"span7\">\n			            <div class=\"span2\" style=\"width:190px\">\n			                <div id=\"otv_naiyacontainer\" style=\"min-width: 100px; height: 350px; margin: 0 auto\"></div>\n			            </div>\n			            <div class=\"span2\" style=\"width:190px\">\n			                <div id=\"otv_tanxingcontainer\" style=\"min-width: 100px; height: 350px; margin: 0 auto\"></div>\n			            </div>\n			            <div class=\"span2\" style=\"width:190px\">\n			                <div id=\"otv_wanqucontainer\" style=\"min-width: 100px; height: 350px; margin: 0 auto\"></div>\n			            </div>\n		            </div>\n		        </div>\n			</div>\n		</section>\n		\n		<!-- Start parallax -->\n		<section class=\"parallax parallax-bgost2\">\n		    <div class=\"page-spacer\">\n		        <div class=\"container\">\n		            <div class=\"row margintop50\">\n		                <div class=\"span12 aligncenter\">\n		                    <h3 style=\"color:#CC9500\">OSTEOPAL&reg;V以稳定作用缓解痛楚</h3>\n		                </div>\n		            </div>\n		        </div>\n		    </div>\n		</section>\n		<!-- End parallax -->\n		\n		\n		\n		<section class=\"page-contain\">\n			<div class=\"container\">\n				<div class=\"row\">\n		            <h4>成功案例</h4>\n		            <div class=\"span14\">\n		               <div class=\"row\">\n		               		<h5>临床病例研究：骨质疏松性椎体骨折的椎体成形术</h5>\n		               		<div class=\"span4\">\n		               			<table>\n		               				<tr valign=\"top\">\n		               					<td width=\"80px\"><b>手术方法：</b></td>\n		               					<td>椎体成形术</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>诊断：</b></td>\n		               					<td>疼痛、急性骨质疏松性骨折 T4, T5, T6, T7</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>病例：</b></td>\n		               					<td>接受皮质激素治疗的 55 岁男性患者</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>来源：</b></td>\n		               					<td>Prof. Gangi, Nouvel H?pital Civil/NHC, Strasbourg, France</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>治疗方式：</b></td>\n		               					<td>发生骨质疏松性骨折的椎体 T4-T7 的加固</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>术后：</b></td>\n		               					<td style=\"color:#CC9500\">出色的骨水泥充填成像可视性</td>\n		               				</tr>\n		               			</table>\n		               		</div>\n		               		<div class=\"span2\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/q1.png\" /></div>\n		               			<div>术前</div>\n		               		</div>\n		               		<div class=\"span2\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/q2.png\" /></div>\n		               			<div>术前</div>\n		               		</div>\n		               		<div class=\"span2\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/s1.png\" /></div>\n		               			<div>术后</div>\n		               		</div>\n		               		<div class=\"span2\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/s2.png\" /></div>\n		               			<div>术后</div>\n		               		</div>\n		               </div>\n		               <hr />\n		               <div class=\"row\">\n		               		<h5>临床病例研究：骨质疏松导致脊椎体的局部骨折</h5>\n		               		<div class=\"span6\">\n		               			<table>\n		               				<tr valign=\"top\">\n		               					<td width=\"120px\"><b>症因：</b></td>\n		               					<td>尤其是中老年患者经常感到背部疼痛，\n		               					原因是骨质疏松导致的脊椎体局部骨折。\n		               					许多保守疗法会导致并发症、\n		               					而且效果往往不是很理想。\n		               					而基于内部力量支撑原理的外科治疗，\n		               					在技术实现上有难度、因而会给患者带来心理压力。\n		               					这就是为什么许多外科医生趋于使用微创脊椎体填充及稳定术。</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td><b>安全的解决方案∶</b></td>\n		               					<td style=\"color:#CC9500\">由内而外强化地填充 及稳定脊椎</td>\n		               				</tr>\n		               				<tr valign=\"top\">\n		               					<td></td>\n		               					<td style=\"color:#777777\">在PVP（微创经皮椎体成型术）中，\n		               					即用一到两根穿刺针将低粘度的骨水泥注入熔合脊椎体内。\n		               					骨水泥中添加了二氧化锆作为显影剂。这样，骨水泥的注入在CT和透视等影像技术的辅助下得以精确而安全地完成。\n		               					不久骨水泥就固化。椎骨由此得到自内而外的稳定、患者的痛苦得到即刻而持久的缓解。</td>\n		               				</tr>\n		               			</table>\n		               		</div>\n		               		<div class=\"span3\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/c1.png\" /></div>\n		               			<div>连续两段椎体骨折 通过采用\nOSTEOPAL&reg; V 一次稳定成型。\n在高度显影剂的帮助下， 可以\n清晰的观察到骨水泥。</div>\n		               		</div>\n		               		<div class=\"span3\" style=\"text-align:center;\">\n		               			<div><img src=\"/themes/lm/images/c2.png\" /></div>\n		               			<div>侧视图显示骨水泥如何有效的渗\n入脊椎体。</div>\n		               		</div>\n		               </div>\n		            </div>\n		        </div>\n			</div>\n		</section>','A','2014-11-10 00:52:23',1,'2014-11-10 00:52:23',1);
/*!40000 ALTER TABLE `tb_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_product_category`
--

DROP TABLE IF EXISTS `tb_product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_product_category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `seq` varchar(10) NOT NULL,
  `status` char(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_product_category`
--

LOCK TABLES `tb_product_category` WRITE;
/*!40000 ALTER TABLE `tb_product_category` DISABLE KEYS */;
INSERT INTO `tb_product_category` VALUES (1,'HERAEUS','1','A','2014-10-29 14:04:38',1,'2014-11-04 16:44:43',1);
INSERT INTO `tb_product_category` VALUES (2,'MAST','2','A','2014-10-29 14:05:08',1,'2014-11-04 17:05:55',1);
/*!40000 ALTER TABLE `tb_product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_province`
--

DROP TABLE IF EXISTS `tb_province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_province` (
  `serialId` int(11) NOT NULL,
  `provinceId` varchar(20) DEFAULT NULL,
  `provinceName` varchar(20) DEFAULT NULL,
  `provinceUpId` varchar(20) DEFAULT NULL,
  `provinceUpIdNum` int(11) DEFAULT NULL,
  `provincePath` varchar(100) DEFAULT NULL,
  `provinceType` varchar(20) DEFAULT NULL,
  `provinceTypeNum` int(11) DEFAULT NULL,
  `shortName` varchar(11) DEFAULT NULL,
  `spell` varchar(20) DEFAULT NULL,
  `areaId` varchar(11) DEFAULT NULL,
  `postCode` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`serialId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_province`
--

LOCK TABLES `tb_province` WRITE;
/*!40000 ALTER TABLE `tb_province` DISABLE KEYS */;
INSERT INTO `tb_province` VALUES (1,'001001','北京市','001',0,'中国/北京','市',2,'bj','Beijing','010','100000');
INSERT INTO `tb_province` VALUES (2,'001002','天津市','001',0,'中国/天津','市',2,'tj','Tianjin','022','300000');
INSERT INTO `tb_province` VALUES (3,'001003','河北省','001',0,'中国/河北','省',2,'hb','Hebei','null','null');
INSERT INTO `tb_province` VALUES (4,'001004','山西省','001',0,'中国/山西','省',2,'sx','Shaanxi','null','null');
INSERT INTO `tb_province` VALUES (5,'001005','内蒙古自治区','001',0,'中国/内蒙古','自治区',2,'nmg','Mongol','null','null');
INSERT INTO `tb_province` VALUES (6,'001006','辽宁省','001',0,'中国/辽宁','省',2,'ln','Liaoning','null','null');
INSERT INTO `tb_province` VALUES (7,'001007','吉林省','001',0,'中国/吉林','省',2,'jl','Jilin','null','null');
INSERT INTO `tb_province` VALUES (8,'001008','黑龙江省','001',0,'中国/黑龙江','省',2,'hlj','Heilongjiang','null','null');
INSERT INTO `tb_province` VALUES (9,'001009','上海市','001',0,'中国/上海','市',2,'sh','Shanghai','021','200000');
INSERT INTO `tb_province` VALUES (10,'001010','江苏省','001',0,'中国/江苏','省',2,'js','Jiangsu','null','null');
INSERT INTO `tb_province` VALUES (11,'001011','浙江省','001',0,'中国/浙江','省',2,'zj','Zhejiang','null','null');
INSERT INTO `tb_province` VALUES (12,'001012','安徽省','001',0,'中国/安徽','省',2,'ah','Anhui','null','null');
INSERT INTO `tb_province` VALUES (13,'001013','福建省','001',0,'中国/福建','省',2,'fj','Fujian','null','null');
INSERT INTO `tb_province` VALUES (14,'001014','江西省','001',0,'中国/江西','省',2,'jx','Jiangxi','null','null');
INSERT INTO `tb_province` VALUES (15,'001015','山东省','001',0,'中国/山东','省',2,'sd','Shandong','null','null');
INSERT INTO `tb_province` VALUES (16,'001016','河南省','001',0,'中国/河南','省',2,'hn','Henan','null','null');
INSERT INTO `tb_province` VALUES (17,'001017','湖北省','001',0,'中国/湖北','省',2,'hb','Hubei','null','null');
INSERT INTO `tb_province` VALUES (18,'001018','湖南省','001',0,'中国/湖南','省',2,'hn','Hunan','null','null');
INSERT INTO `tb_province` VALUES (19,'001019','广东省','001',0,'中国/广东','省',2,'gd','Guangdong','null','null');
INSERT INTO `tb_province` VALUES (20,'001020','广西省','001',0,'中国/广西','壮族自治区',2,'gx','Guangxi','null','null');
INSERT INTO `tb_province` VALUES (21,'001021','海南省','001',0,'中国/海南','省',2,'hn','Hainan','null','null');
INSERT INTO `tb_province` VALUES (22,'001022','重庆市','001',0,'中国/重庆','市',2,'cq','Chongqing','023','400000');
INSERT INTO `tb_province` VALUES (23,'001023','四川省','001',0,'中国/四川','省',2,'sc','Sichuan','null','null');
INSERT INTO `tb_province` VALUES (24,'001024','贵州省','001',0,'中国/贵州','省',2,'gz','Guizhou','null','null');
INSERT INTO `tb_province` VALUES (25,'001025','云南省','001',0,'中国/云南','省',2,'yn','Yunnan','null','null');
INSERT INTO `tb_province` VALUES (26,'001026','西藏自治区','001',0,'中国/西藏','自治区',2,'xc','Xizang','null','null');
INSERT INTO `tb_province` VALUES (27,'001027','陕西省','001',0,'中国/陕西','省',2,'sx','Shanxi','null','null');
INSERT INTO `tb_province` VALUES (28,'001028','甘肃省','001',0,'中国/甘肃','省',2,'gs','Gansu','null','null');
INSERT INTO `tb_province` VALUES (29,'001029','青海省','001',0,'中国/青海','省',2,'qh','Qinghai','null','null');
INSERT INTO `tb_province` VALUES (30,'001030','宁夏回族自治区','001',0,'中国/宁夏','回族自治区',2,'nx','Ningxia','null','null');
INSERT INTO `tb_province` VALUES (31,'001031','新疆维吾尔自治区','001',0,'中国/新疆','维吾尔自治区',2,'xj','Xinjiang','null','null');
INSERT INTO `tb_province` VALUES (32,'001032','香港特别行政区','001',0,'中国/香港','特别行政区',2,'xg','Xianggang','852','null');
INSERT INTO `tb_province` VALUES (33,'001033','澳门特别行政区','001',0,'中国/澳门','特别行政区',2,'am','Aomen','853','null');
INSERT INTO `tb_province` VALUES (34,'001034','台湾省','001',0,'中国/台湾','省',2,'tw','Taiwan','886','null');
/*!40000 ALTER TABLE `tb_province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_requisition`
--

DROP TABLE IF EXISTS `tb_requisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_requisition` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `company_city` varchar(100) NOT NULL,
  `company_address` varchar(300) NOT NULL,
  `company_phone` varchar(100) NOT NULL,
  `company_website` varchar(100) NOT NULL,
  `knew` varchar(1) NOT NULL,
  `message` varchar(300) NOT NULL,
  `question` varchar(300) NOT NULL,
  `status` varchar(1) NOT NULL,
  `remarks` varchar(300) NOT NULL,
  `applied_date` datetime NOT NULL,
  `updated_date` datetime DEFAULT NULL,
  `updated_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_requisition`
--

LOCK TABLES `tb_requisition` WRITE;
/*!40000 ALTER TABLE `tb_requisition` DISABLE KEYS */;
INSERT INTO `tb_requisition` VALUES (1,'姓名','职务','alucard263096@126.com','13751082562','359304951','公司名称','公司所在地','公司地址','13751082562','','Y','我的留言','您希望进一步了解的信息是','A','测试','2014-11-16 13:52:28','2014-11-16 13:55:04',1);
/*!40000 ALTER TABLE `tb_requisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_seq`
--

DROP TABLE IF EXISTS `tb_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_seq` (
  `table_name` varchar(50) NOT NULL,
  `curval` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_seq`
--

LOCK TABLES `tb_seq` WRITE;
/*!40000 ALTER TABLE `tb_seq` DISABLE KEYS */;
INSERT INTO `tb_seq` VALUES ('tb_user',42);
INSERT INTO `tb_seq` VALUES ('tb_download_category',1);
INSERT INTO `tb_seq` VALUES ('tb_download_file',2);
/*!40000 ALTER TABLE `tb_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_user` (
  `user_id` int(11) NOT NULL,
  `login_id` varchar(12) NOT NULL,
  `password` varchar(32) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `remarks` varchar(1000) DEFAULT NULL,
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_user` int(11) NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user`
--

LOCK TABLES `tb_user` WRITE;
/*!40000 ALTER TABLE `tb_user` DISABLE KEYS */;
INSERT INTO `tb_user` VALUES (1,'admin','e19d5cd5af0378da05f63f891c7467af','System Administrator','info@i4deas.com','','A',1,'2011-02-07 17:26:55',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user` VALUES (2,'jessy.lin','d41d8cd98f00b204e9800998ecf8427e','林汉婷','jessy.lin@ldmhgp.com','','A',1,'2014-08-09 10:28:31',1,'2014-11-16 13:54:06');
/*!40000 ALTER TABLE `tb_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user_access_right`
--

DROP TABLE IF EXISTS `tb_user_access_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_user_access_right` (
  `user_id` int(11) NOT NULL,
  `function_id` int(11) NOT NULL,
  `right_id` int(11) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user_access_right`
--

LOCK TABLES `tb_user_access_right` WRITE;
/*!40000 ALTER TABLE `tb_user_access_right` DISABLE KEYS */;
INSERT INTO `tb_user_access_right` VALUES (1,2,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,3,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,3,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,4,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,4,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,11,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,11,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,12,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,12,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,10,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,10,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,6,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,6,3,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,13,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,8,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (1,9,2,1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_access_right` VALUES (2,2,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,3,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,3,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,4,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,4,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,11,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,11,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,12,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,12,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,6,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,6,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,10,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,10,3,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,13,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,8,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,9,2,1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_access_right` VALUES (2,9,3,1,'2014-11-16 13:54:06');
/*!40000 ALTER TABLE `tb_user_access_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_user_function`
--

DROP TABLE IF EXISTS `tb_user_function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_user_function` (
  `user_id` int(11) NOT NULL,
  `function_id` int(11) NOT NULL,
  `status` char(1) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user_function`
--

LOCK TABLES `tb_user_function` WRITE;
/*!40000 ALTER TABLE `tb_user_function` DISABLE KEYS */;
INSERT INTO `tb_user_function` VALUES (1,2,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,3,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,4,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,11,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,12,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,10,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,6,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,13,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,8,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (1,9,'A',1,'2014-11-16 13:54:00');
INSERT INTO `tb_user_function` VALUES (2,2,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,3,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,4,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,11,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,12,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,6,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,10,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,13,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,8,'A',1,'2014-11-16 13:54:06');
INSERT INTO `tb_user_function` VALUES (2,9,'A',1,'2014-11-16 13:54:06');
/*!40000 ALTER TABLE `tb_user_function` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_website_banner`
--

DROP TABLE IF EXISTS `tb_website_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_website_banner` (
  `id` int(11) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `cont` varchar(255) NOT NULL,
  `seq` varchar(10) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`id`,`slogan`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_website_banner`
--

LOCK TABLES `tb_website_banner` WRITE;
/*!40000 ALTER TABLE `tb_website_banner` DISABLE KEYS */;
INSERT INTO `tb_website_banner` VALUES (1,'<span style=\"color:#007dc6\">SurgiWrap</span> 唯一兼具支撑保护与隔离的聚乳酸可吸收膜。','产品','<span style=\"color:#007dc6\">聚乳酸手术保护膜</span>','<span style=\"color:#007dc6\">SurgiWrap</span>聚乳酸脂手术保护膜（简称“MAST膜”）是由美国MAST Biosurgery Inc.研制生产。','3','14111017003Operatie-1-e1408646748320.jpg','http://www.gushuini.com/product/detail.php?id=1','A');
INSERT INTO `tb_website_banner` VALUES (2,'<span style=\"color:#FFDC35\">OSTEOPAL&reg; V</span>由内而外强化脊椎、再现灵活','产品','<span style=\"color:#FFDC35\">脊柱外科领域的黄金标准。</span>','50多年来，德国制造的贺利氏一直是全球骨水泥的领先品牌。 PALACOS? 累积数十年的成功经验，使得贺利氏骨水泥系列不断扩展。OSTEOPAL? 脊柱骨水泥可满足严苛的椎体加固要求，由内而外强化脊椎、再现灵活。\n','2','1409221703811350592_101205133000_2.jpg','http://www.gushuini.com/product/detail.php?id=4','A');
INSERT INTO `tb_website_banner` VALUES (3,'公司拥有稳定成熟的产品销售市场，经营的产品为同领域中的优秀产品，公司负责德国骨水泥产品在大陆地区的渠道销售管理及市场技术支持服务。','加入我们','雷德睦华诚邀您的加盟','公司拥有稳定成熟的产品销售市场，经营的产品为同领域中的优秀产品，公司负责德国骨水泥产品在大陆地区的渠道销售管理及市场技术支持服务。','','14090814031HMT_Walzwerk.jpg',NULL,'D');
INSERT INTO `tb_website_banner` VALUES (4,'<span style=\"color:#74B726\">PALACOS&reg; </span>假体置换术的黄金标准，50多年的品质和安全性。','产品','<span style=\"color:#74B726\">品质、专业、创新。适用于关节置换术的现代化骨水泥技术。</span>','50 多年来，PALACOS? 骨水泥一直是植入物永久性骨锚定领域的黄金标准。完美\n融合现有的专业知识与市场需求 – 贺利氏成功的秘诀。基于数十年的研发工作，\n贺利氏得以持续开发创新产品，扩大产品组合。除了选择合适的骨水泥外，现代化骨\n水泥技术的应用也对人工关节置换手术的成功与否起着至关重要的作用。为此，贺\n利氏推出全面的产品组合，从高品质 PALACOS? 骨水泥到创新 PALAMIX? 真空混\n合系统再到用于清洗骨床的脉冲冲洗系统。','1','1411101602314092.jpg','http://www.gushuini.com/product/detail.php?id=3','A');
/*!40000 ALTER TABLE `tb_website_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_website_base`
--

DROP TABLE IF EXISTS `tb_website_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_website_base` (
  `website_name` varchar(200) DEFAULT NULL,
  `favfile` varchar(200) DEFAULT NULL,
  `contacter` varchar(200) DEFAULT NULL,
  `qq` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `seo_title` varchar(200) DEFAULT NULL,
  `seo_keywords` varchar(200) DEFAULT NULL,
  `seo_description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_website_base`
--

LOCK TABLES `tb_website_base` WRITE;
/*!40000 ALTER TABLE `tb_website_base` DISABLE KEYS */;
INSERT INTO `tb_website_base` VALUES ('雷德睦华官方网站','1409191804914090721009favicon.ico','','','','','','','骨水泥专家','骨水泥,Heraeus,MAST,手术膜','骨水泥,Heraeus,MAST,手术膜');
/*!40000 ALTER TABLE `tb_website_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hdm0290036_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-01 21:28:14
